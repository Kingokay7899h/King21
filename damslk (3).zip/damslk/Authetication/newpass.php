<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");


include "db_config.php"; // Include your database connection file

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    header("Content-Type: application/json");

    if (!isset($_SESSION["reset_email"])) {
        echo json_encode(["status" => "error", "message" => "Session expired. Request a new password reset."]);
        exit;
    }

    $email = $_SESSION["reset_email"];
    $newPassword = $_POST["newPassword"] ?? "";

    // Validate password
    if (strlen($newPassword) < 8 || !preg_match("/[A-Z]/", $newPassword) || 
        !preg_match("/[a-z]/", $newPassword) || !preg_match("/\d/", $newPassword) ||
        !preg_match("/[!@#$%^&*]/", $newPassword)) {
        echo json_encode(["status" => "error", "message" => "Password must contain at least 8 characters, one uppercase letter, one lowercase letter, one number, and one special character."]);
        exit;
    }

    // Hash the new password
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

    // Update password in the database
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
    if (!$stmt) {
        echo json_encode(["status" => "error", "message" => "Database error."]);
        exit;
    }
    $stmt->bind_param("ss", $hashedPassword, $email);
    
    if ($stmt->execute()) {
        unset($_SESSION["reset_email"]); // Clear session after reset
        echo json_encode(["status" => "success", "redirect" => "login.html"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Password reset failed. Try again."]);
    }

    $stmt->close();
    $conn->close();
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - DAMS</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@600&family=Poppins:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #1570EF;
            --accent-yellow: #EDCA63;
            --text-gray: #666666;
            --border-color: rgba(102, 102, 102, 0.35);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Poppins, sans-serif;
            min-height: 100vh;
            background-color: #FFFFFF;
        }
        
        .page-container {
            padding: 2rem;
        }
        
        .brand-logo {
            position: absolute;
            top: 60px;
            left: 50px;
            color: var(--primary-blue);
            font-weight: 600;
            font-size: clamp(2rem, 2vw, 2.5rem);
        }
        
        .reset-password-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: calc(100vh - 120px);
        }
        
        .password-form {
            width: 100%;
            max-width: 568px;
            text-align: center;
        }
        
        .form-title {
            color: var(--accent-yellow);
            font-size: 2rem;
            margin-bottom: 2rem;
        }
        
        .form-fields {
            display: flex;
            flex-direction: column;
            gap: 30px;
            margin-bottom: 55px;
        }
        
        .input-group {
            text-align: left;
            max-width: 500px; 
            margin-left: auto;
            margin-right: auto;
        }
        
        .input-group label {
            display: block;
            color: var(--text-gray);
            font-size: 16px;
            margin-bottom: 4px;
        }
        
        .input-group input {
            width: 100%;
            height: 50px;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 0 16px;
            font-size: 16px;
        }
        
        .submit-button {
            background-color: #111111;
            color: #FFFFFF;
            border: none;
            border-radius: 32px;
            padding: 12px 40px;
            font-size: 20px;
            cursor: pointer;
            transition: background-color 0.2s ease;
        }
        
        .submit-button:hover {
            background-color: #333333;
        }

        .status-message {
            margin-top: 15px;
            font-size: 16px;
            font-weight: bold;
        }

        .error {
            color: red;
        }

        .success {
            color: green;
        }
    </style>
</head>
<body>
    <div class="page-container">
        <header>
            <h1 class="brand-logo">DAMS</h1>
        </header>
        <main class="reset-password-container">
            <form id="resetPasswordForm" class="password-form">
                <h2 class="form-title">Create New Password</h2>
                <div class="form-fields">
                    <div class="input-group">
                        <label for="newPassword">Set New Password</label>
                        <input type="password" id="newPassword" required>
                    </div>
                    <div class="input-group">
                        <label for="confirmPassword">Confirm New Password</label>
                        <input type="password" id="confirmPassword" required>
                    </div>
                </div>
                <button type="submit" class="submit-button">Reset Password</button>
                <p id="formStatus" class="status-message"></p>
            </form>
        </main>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const form = document.getElementById('resetPasswordForm');
            const newPassword = document.getElementById('newPassword');
            const confirmPassword = document.getElementById('confirmPassword');
            const formStatus = document.getElementById('formStatus');

            form.addEventListener('submit', async (e) => {
                e.preventDefault();

                if (newPassword.value.length < 8 || 
                    !/[A-Z]/.test(newPassword.value) || 
                    !/[a-z]/.test(newPassword.value) || 
                    !/\d/.test(newPassword.value) || 
                    !/[!@#$%^&*]/.test(newPassword.value)) {
                    formStatus.textContent = "Password must be at least 8 characters, contain uppercase, lowercase, a number, and a special character.";
                    formStatus.className = "status-message error";
                    return;
                }

                if (newPassword.value !== confirmPassword.value) {
                    formStatus.textContent = "Passwords do not match!";
                    formStatus.className = "status-message error";
                    return;
                }

                const response = await fetch("newpass.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/x-www-form-urlencoded" },
                    body: `newPassword=${encodeURIComponent(newPassword.value)}`
                });

                const data = await response.json();
                if (data.status === "success") {
                    formStatus.textContent = "Password successfully reset! Redirecting...";
                    formStatus.className = "status-message success";
                    setTimeout(() => window.location.href = data.redirect, 2000);
                } else {
                    formStatus.textContent = data.message;
                    formStatus.className = "status-message error";
                }
            });
        });

        // Prevent back navigation after login/reset
history.pushState(null, null, location.href);
window.onpopstate = function () {
    history.go(1);
};

    </script>
</body>
</html>
