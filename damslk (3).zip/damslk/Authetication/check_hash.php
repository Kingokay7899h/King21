<?php
$entered_password = "Rigved4321";
$stored_hash = "$2y$10$9w9I64TbshP.vz2FMDQyIugsWM/UeqgLS0p4RKK/.69ErImFHz3te";

if (password_verify($entered_password, $stored_hash)) {
    echo "✅ Password matches the stored hash!";
} else {
    echo "❌ Password does NOT match the stored hash.";
}
?>
