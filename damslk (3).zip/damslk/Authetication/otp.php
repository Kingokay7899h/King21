<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

$email = $_GET["email"] ?? null; // Retrieve email from query parameter

if (!$email) {
    die("Email not found. Please go back to the forgot password page.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="OTP Verification Page">
    <title>OTP Verification</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Poppins:wght@400;600&family=Merriweather&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        :root {
            --primary-color: #1570EF;
            --secondary-color: #EDCA63;
            --text-dark: #1E1E1E;
            --text-light: #FFFFFF;
            --border-color: rgba(102, 102, 102, 0.35);
            --focus-outline: 2px solid #1570EF;
            --error-color: #DC2626;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            font-family: 'Inter', sans-serif;
            background-color: var(--text-light);
            line-height: 1.5;
        }

        .skip-link {
            position: absolute;
            top: -40px;
            left: 0;
            background: var(--primary-color);
            color: var(--text-light);
            padding: 8px;
            z-index: 100;
            transition: top 0.3s;
        }

        .skip-link:focus {
            top: 0;
        }

        .brand-header {
            padding: 2rem;
            text-align: left;
        }

        .brand-logo {
            position: absolute;
            top: 60px;
            left: 50px;
            color: var(--primary-color);
            font-family:Poppins;
            font-weight: 600;
            font-size: clamp(2rem, 2vw, 2.5rem);
            margin: 0;
            text-decoration: none; 
        }

        .main-content {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items:flex-start;
            padding: 2rem;

        }

        .verification-container {
            width: 100%;
            max-width: 600px;
            text-align: center;
            margin-top: 60px;
        }

        .verification-title {
            color: var(--secondary-color);
            font-size: 2.5rem;
            font-family:Poppins;
            margin-bottom: 1.5rem;
        }

        .verification-message {
            color: var(--text-dark);
            font-size: 1rem;
            font-family: 'Merriweather', serif;
            margin-bottom: 2rem;
        }

        .otp-form {
            width: 100%;
            max-width: 400px;
            margin: 0 auto;
        }

        .otp-input-group {
            display: flex;
            justify-content: center;
            gap: 2.5rem;
            margin-bottom: 2rem;
        }

        .otp-input {
            width: 4rem;
            height: 4rem;
            border: 1px solid var(--border-color);
            border-radius: 0.75rem;
            text-align: center;
            font-size: 1.5rem;
            background: transparent;
            transition: border-color 0.3s ease;
        }

        .otp-input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 2px rgba(21, 112, 239, 0.2);
        }

        .otp-input:focus-visible {
            outline: var(--focus-outline);
            outline-offset: 2px;
        }

        .submit-button {
            width: 100%;
            max-width: 304px;
            padding: 1rem 2rem;
            border: none;
            border-radius: 2rem;
            background-color: var(--text-dark);
            color: var(--text-light);
            font-size: 1.5rem;
            font-family: 'Poppins', sans-serif;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .submit-button:hover {
            background-color: #333;
            transform: translateY(-1px);
        }

        .submit-button:focus {
            outline: none;
            box-shadow: 0 0 0 2px var(--text-dark), 0 0 0 4px var(--text-light);
        }

        .submit-button:active {
            transform: translateY(1px);
        }

        .error-message {
            color: var(--error-color);
            font-size: 0.875rem;
            margin-top: 0.5rem;
            display: none;
        }

        .error-message.visible {
            display: block;
        }

        @media (max-width: 768px) {
            .verification-title {
                font-size: 2rem;
            }

            .otp-input {
                width: 3rem;
                height: 3rem;
                font-size: 1.25rem;
            }

            .submit-button {
                padding: 0.75rem 1.5rem;
                font-size: 1.25rem;
            }
        }

        @media screen and (prefers-reduced-motion: reduce) {
            * {
                transition: none !important;
            }
        }

        @media (forced-colors: active) {
            .submit-button {
                border: 2px solid currentColor;
            }
        }
    </style>
</head>
<body>
    <a href="#main-content" class="skip-link">Skip to main content</a>
    
    <header class="brand-header" role="banner">
        <a href="otp.php" class="brand-logo" aria-label="DAMS Home">DAMS</a>
    </header>

    <main id="main-content" class="main-content" role="main">
        <div class="verification-container">
            <h1 id="verification-title" class="verification-title">ENTER YOUR CODE</h1>
            <p class="verification-message" id="verification-instructions">
    We sent you an email at <strong><?php echo htmlspecialchars($email); ?></strong>
</p>

            <form action="verify.php" method="POST" class="otp-form">
    <input type="hidden" name="email" value="<?php echo htmlspecialchars($email); ?>">
    
    <div class="otp-input-group">
        <input type="text" class="otp-input" name="otp1" maxlength="1" required>
        <input type="text" class="otp-input" name="otp2" maxlength="1" required>
        <input type="text" class="otp-input" name="otp3" maxlength="1" required>
        <input type="text" class="otp-input" name="otp4" maxlength="1" required>
    </div>
    <button type="submit" class="submit-button">Continue</button>
</form>
        </div>
    </main>
    <script>

document.addEventListener("DOMContentLoaded", () => {
    const form = document.querySelector(".otp-form");
    const inputs = [...document.querySelectorAll(".otp-input")];
    const errorMessage = document.querySelector(".error-message");
    const submitButton = document.querySelector(".submit-button"); // Fixed selector

    // Auto-focus next input when typing
    inputs.forEach((input, index) => {
        input.addEventListener("input", (e) => {
            if (e.target.value.length === 1 && index < inputs.length - 1) {
                inputs[index + 1].focus();
            }
        });

        // Allow only numbers
        input.addEventListener("keypress", (e) => {
            if (!/\d/.test(e.key)) {
                e.preventDefault();
            }
        });
    });

    form.addEventListener("submit", async (e) => {
        e.preventDefault(); // Stop normal form submission

        submitButton.disabled = true; // Prevent multiple clicks

        // Get the entered OTP
        const otp = inputs.map(input => input.value.trim()).join("");

        if (otp.length !== 4 || !/^\d{4}$/.test(otp)) {
            showError("Please enter a valid 4-digit OTP.");
            submitButton.disabled = false;
            return;
        }

        // Get email from hidden input
        const email = document.querySelector("input[name='email']").value;

        // Send OTP via AJAX
        try {
            const response = await fetch("verify.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: `email=${encodeURIComponent(email)}&otp=${encodeURIComponent(otp)}`
            });

            const data = await response.json(); // Ensure JSON response
            console.log("Response:", data); // Debugging

            if (data.status === "success") {
                window.location.href = data.redirect; // Redirect on success
            } else {
                showError(data.message || "Invalid OTP. Try again.");
                submitButton.disabled = false;
            }
        } catch (error) {
            showError("Server error. Try again later.");
            console.error("Error:", error);
            submitButton.disabled = false;
        }
    });

    function showError(message) {
        errorMessage.textContent = message;
        errorMessage.classList.add("visible");
    }
});
  
   // Prevent back navigation after login/reset
history.pushState(null, null, location.href);
window.onpopstate = function () {
    history.go(1);
};

 
    </script>
</body>
</html>