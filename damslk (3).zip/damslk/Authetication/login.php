<?php
session_start();  // Ensure session is started at the very beginning

error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "localhost";
$username = "root";
$password = ""; 
$dbname = "asset_management"; 

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    $user = $conn->real_escape_string($user);


    $sql = "SELECT password, role, name, lab_name, lab_id FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $user);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $hashed_password = $row['password'];
        $role = strtolower(trim($row['role']));
        $lab_name = $row['lab_name'];
        $lab_id = $row['lab_id'];
        $user_name = $row['name'];

        if (password_verify($pass, $hashed_password)) {
            // ✅ Store correct session values
            $_SESSION['user'] = $user;
            $_SESSION['email'] = $user;  // 🔹 FIXED: Store email properly
            $_SESSION['role'] = $role;
            $_SESSION['lab_name'] = $lab_name;
            $_SESSION['lab_id'] = $lab_id;
            $_SESSION['name'] = $user_name;

            // ✅ Debugging: Check if session values are set properly
            error_log("Session Email: " . $_SESSION['email']);
            error_log("Session Role: " . $_SESSION['role']);

            // ✅ Redirect based on role
            switch ($role) {
                case 'admin':
                    header("Location: ../Admin/admin.html");
                    break;
                case 'hod':
                    header("Location: ../Hod/hod.html");
                    break;

                case 'store':
                    header("Location: ../stores/stores.html");
                    break;


                    case 'purchase committee':
                        header("Location: ../committee/pac.html");
                        break;
                        
                case 'lab assistant':
                    if (empty($lab_name)) {
                        echo "<script>alert('Lab Assistant must have a lab assigned. Contact Admin.');</script>";
                        exit();
                    }
                    header("Location: ../lab_assistant/lab_assistant.php");
                    break;
                case 'lab faculty incharge':
                    if (empty($lab_name)) {
                        echo "<script>alert('Lab Faculty Incharge must have a lab assigned. Contact Admin.');</script>";
                        exit();
                    }
                    header("Location: ../lab_faculty_incharge/lab_faculty_incharge.php");
                    break;
                default:
                    echo "<script>alert('Unauthorized role access. Contact Admin.');</script>";
                    exit();
            }
            exit();
        } else {
            echo "<script>alert('Invalid username or password. Please try again.');</script>";
        }
    } else {
        echo "<script>alert('Invalid username or password. Please try again.');</script>";
    }
    // $sql = "SELECT password, role, lab_name FROM users WHERE email = ?";
    // $stmt = $conn->prepare($sql);
    // $stmt->bind_param("s", $user);
    // $stmt->execute();
    // $result = $stmt->get_result();

  
    
    // if ($result->num_rows > 0) {
    //     $row = $result->fetch_assoc();
    //     $hashed_password = $row['password'];
    //     $role = strtolower(trim($row['role']));
    //     $lab_name = $row['lab_name'];
    
    //     // Debugging: Check what password is stored in the database
    //     echo "Stored Hash: " . $hashed_password . "<br>";
    //     echo "Entered Password: " . $pass . "<br>";
    
    //     if (password_verify($pass, $hashed_password)) {
    //         echo "✅ Password verified! Logging in...";
    //         exit();
    //     } else {
    //         echo "❌ Incorrect password.";
    //         exit();
    //     }
    // }
    


    
    

    
    $stmt->close();
}
$conn->close();
?>
