<?php
session_start();
header('Content-Type: application/json');
include "db_config.php"; // Ensure database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"] ?? null;
    $entered_otp = $_POST["otp"] ?? null; // Get full OTP from AJAX

    if (!$email || !$entered_otp || !preg_match('/^\d{4}$/', $entered_otp)) {
        echo json_encode(["status" => "error", "message" => "Invalid email or OTP."]);
        exit;
    }

    // Fetch OTP from the database
    $stmt = $conn->prepare("SELECT otp, expires_at FROM password_reset WHERE email = ?");
    if (!$stmt) {
        echo json_encode(["status" => "error", "message" => "Database error."]);
        exit;
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo json_encode(["status" => "error", "message" => "No OTP found."]);
        exit;
    }

    $row = $result->fetch_assoc();
    $stored_otp = $row["otp"];
    $expires_at = $row["expires_at"];
    $stmt->close();

    // Check if OTP is expired
    if (strtotime($expires_at) < time()) {
        echo json_encode(["status" => "error", "message" => "OTP has expired. Request a new one."]);
        exit;
    }

    // Validate OTP
    if ($stored_otp === $entered_otp) {
        // Delete OTP after verification
        $delete_stmt = $conn->prepare("DELETE FROM password_reset WHERE email = ?");
        $delete_stmt->bind_param("s", $email);
        $delete_stmt->execute();
        $delete_stmt->close();

        $_SESSION["reset_email"] = $email; // Store for password reset

        echo json_encode(["status" => "success", "redirect" => "newpass.php"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid OTP. Try again."]);
    }
}
?>
