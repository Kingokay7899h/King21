<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'db_config.php';
require 'vendor/autoload.php'; // Load PHPMailer

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die(json_encode(["status" => "error", "message" => "Invalid email address."]));
    }

    // Check if email exists in users table
    $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        die(json_encode(["status" => "error", "message" => "Email not registered."]));
    }
    $stmt->close();

    // Generate OTP
    $otp = rand(1000, 9999);
    $expiry = date("Y-m-d H:i:s", strtotime("+10 minutes")); // OTP expires in 10 minutes

    // Store OTP in DB (overwrite if exists)
    $stmt = $conn->prepare("INSERT INTO password_reset (email, otp, expires_at) VALUES (?, ?, ?) 
                            ON DUPLICATE KEY UPDATE otp=?, expires_at=?");
    $stmt->bind_param("sssss", $email, $otp, $expiry, $otp, $expiry);

    if ($stmt->execute()) {
        // Send OTP via email
        $mail = new PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com'; // Gmail SMTP server
            $mail->SMTPAuth = true;
            $mail->Username = 'userexamp01@gmail.com'; // Your Gmail address
            $mail->Password = 'powl sptf difk rgkv'; // Your Gmail app password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption
            $mail->Port = 587; // TCP port to connect to

            // Sender and recipient
            $mail->setFrom('userexamp01@gmail.com', 'DAMS Support'); // Sender email and name
            $mail->addAddress($email); // Recipient email

            // Email content
            $mail->isHTML(true); // Set email format to HTML
            $mail->Subject = 'Your OTP for Password Reset'; // Email subject
            $mail->Body = "<h3>Your OTP code is: <b>$otp</b></h3><p>This code is valid for 5 minutes.</p>"; // Email body

            // Send email
            $mail->send();

            // Redirect to OTP page with email as a query parameter
            echo json_encode([
                "status" => "success",
                "message" => "OTP sent to your email.",
                "redirect" => "otp.php?email=" . urlencode($email) // Pass email in URL
            ]);
        } catch (Exception $e) {
            echo json_encode(["status" => "error", "message" => "OTP email sending failed."]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Database error. Try again!"]);
    }
    $stmt->close();
}
$conn->close();
?>