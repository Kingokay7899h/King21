<?php
session_start();
include '../Authetication/db_config.php'; // Ensure this file includes your database connection setup

// Check if user is logged in and has a lab assigned
if (!isset($_SESSION['lab_name'])) {
    die("Access denied. Lab not assigned.");
}

$lab_name = $_SESSION['lab_name'];

$query = "SELECT * FROM requisitions WHERE lab_name = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $lab_name);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab Assistant Dashboard</title>
    <link rel="stylesheet" href="lab_assistant.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div id="dashboard-container" class="d-flex">
        <!-- Sidebar -->
        <div id="sidebar" class="d-flex flex-column p-3 text-white">
            <h4 class="mb-4">DAMS</h4>
            <ul class="nav nav-pills flex-column mb-auto">
                <li><a href="lab_assistant.php" class="nav-link text-white link-hover "><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="#" class="nav-link text-white link-hover"><i class="fas fa-box"></i> Inventory</a></li>
                <li><a href="../forms/proc.html" class="nav-link text-white link-hover"><i class="fas fa-file-alt"></i> Procurement</a></li>
                <li><a href="user_manage.php" class="nav-link text-white link-hover"><i class="fas fa-exclamation-triangle"></i> Condemnation</a></li>
                <li><a href="user_manage.php" class="nav-link text-white link-hover"><i class="fas fa-wrench"></i> Maintenance</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div id="main-content" class="container-fluid p-4">
            <nav class="navbar navbar-light bg-custom d-flex justify-content-between">
                <button class="btn btn-dark ms-2" id="menu-toggle"><i class="fas fa-bars"></i></button>
                <input class="form-control w-50 ms-1" type="search" placeholder="Search assets...">
                <div>
                    <i class="fas fa-user fa-2x"></i>
                    <span class="ms-1 me-1"><b><?php echo $_SESSION['name']; ?> (Lab Assistant)</b></span>
                </div>
            </nav>
            <h3 class="mt-4">Dashboard</h3>
            <div class="row my-4">
                <div class="col-md-6">
                    <a href="../Inventory/category.html"  class="text-decoration-none">
                        <div class="d-flex btn btn-primary justify-content-center text-center p-3" >Inventory</div>
                    </a>
                </div>
                <div class="col-md-6">
                    <a href="user_manage.php" class="text-decoration-none">
                        <div class="d-flex btn btn-primary justify-content-center text-center p-3">Maintenance</div>
                    </a>
                </div>
            </div>
            <div class="row my-4">
                <div class="col-md-6">
                    <a href="#" class="text-decoration-none">
                        <div class="d-flex justify-content-center btn btn-primary text-center p-3">Requisition Form</div>
                    </a>
                </div>
                <div class="col-md-6">
                    <a href="#" class="text-decoration-none">
                        <div class="d-flex justify-content-center btn btn-primary text-center p-3">Condemnation Form</div>
                    </a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card p-3">
                        <h5>Requisitions for <?php echo $lab_name; ?></h5>
                        <ul class="list-group">
                            <?php while ($row = $result->fetch_assoc()) { ?>
                                <li class="list-group-item">Requisition #<?php echo $row['id']; ?> - <?php echo $row['status']; ?></li>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        document.getElementById("menu-toggle").addEventListener("click", function() {
            document.getElementById("dashboard-container").classList.toggle("collapsed");
        });
    </script>

</body>
</html>

