<?php
$servername = "localhost"; // Change if needed
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "asset_management"; // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the request is a POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the POST request
    var_dump($_POST);
    $labId = $_POST["labId"];
    $cid = $_POST["cid"];
    $itemName = $_POST["itemName"];
    $entryDate = $_POST["entryDate"];
    $itemSpec = $_POST["itemSpec"];
    $indentNo = $_POST["indentNo"];
    $indentDate = $_POST["indentDate"];
    $supplier = $_POST["supplier"];
    $quantity = $_POST["quantity"];
    $billNo = $_POST["billNo"];
    $billDate = $_POST["billDate"];
    $price = $_POST["price"];
    $usedQty = $_POST["usedQty"];
    $balance = $_POST["balance"];
    $la = isset($_POST["la"]) ? 1 : 0; // Checkbox values
    $li = isset($_POST["li"]) ? 1 : 0;
    $hod = isset($_POST["hod"]) ? 1 : 0;
    $remarks = $_POST["remarks"];
    $assetType = $_POST["assetType"];

    // SQL query to insert data into the 'register' table
    $sql = "INSERT INTO register (lab_id, cid, name_of_the_item, date, item_specification, indent_no, indent_date, name_of_supplier, qty, bill_no, bill_date, price, used_qty, balance_qty, la_sign, li_sign, hod_sign, remarks, asset_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare the SQL statement
    $stmt = $conn->prepare($sql);

    // Bind parameters and execute the statement
    $stmt->bind_param("sssssssssssiiiiiiss", 
    $labId, $cid, $itemName, $entryDate, $itemSpec, $indentNo, $indentDate, 
    $supplier, $quantity, $billNo, $billDate, $price, $usedQty, $balance, 
    $la, $li, $hod, $remarks, $assetType);

    if ($stmt->execute()) {
        echo "<script>alert('New record created successfully'); window.location.href = document.referrer;</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "'); window.location.href = document.referrer;</script>";
    }

    $stmt->close();
}

$conn->close();
?>

