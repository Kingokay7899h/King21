<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="admin.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div id="dashboard-container" class="d-flex">
        <!-- Sidebar -->
        <div id="sidebar" class="d-flex flex-column   py-3 ">
            <h4 class="dams ps-4 pt-4 mb-5"><b>DAMS</b></h4>
            <ul class="nav nav-pills flex-column mb-auto">
                <li><a href="admin.html" class="nav-link link-hover" id="dashboard-link"><i class="fas fa-home pe-2 ps-2"></i> Dashboard</a></li>
                <li><a href="user_manage.php" class="nav-link link-hover" id="user-manage-link"><i class="fas fa-users pe-2 ps-2"></i> User Management</a></li>
                <li><a href="#" class="nav-link link-hover" id="inventory-link"><i class="fas fa-box pe-2 ps-2"></i> Inventory</a></li>
                <li><a href="#" class="nav-link link-hover" id="requisition-link"><i class="fas fa-file-alt pe-2 ps-2"></i> Requisition</a></li>
            </ul>

            <!-- <a href="sign_in.html" class="nav-link link-hover mt-auto ms-3 mb-4">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a> -->
        </div>

        
        <!-- Main Content -->
        <div id="main-content" class="container-fluid">
            <div class="row mynav d-flex">
                <nav class="navbar w-100 navbar-light bg-custom d-flex justify-content-between">
                    <span class="ms-3" id="menu-toggle"><i class="fas fa-bars"></i></span>
                    <input class="form-control w-50 " type="search"  placeholder="Search assets...">
                    <div class="username">
                        <i class="far fa-user"></i>
                        <span class="ms-1 me-3">(Admin)</span>
                    </div>
                </nav>
            </div>
            <!-- <h3 class="mt-4">Dashboard</h3> -->
            <h4 class="my-4 ms-3"><b>User Management</b></h4>
            <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addUserModal"><i class="fas fa-user-plus"></i> Add New User</button>

            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr> 
                </thead>
                <tbody>
                    <?php
                    include "db_config.php"; 
                
                    $query = "SELECT * FROM users";
                    $result = mysqli_query($conn, $query);
                
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                                <td><i class='fas fa-user'></i> " . htmlspecialchars($row['name']) . "</td>
                                <td>" . htmlspecialchars($row['email']) . "</td>
                                <td>" . htmlspecialchars($row['role']) . "</td>
                                <td><span class='badge " . ($row['status'] == 'Active' ? 'bg-success' : 'bg-danger') . "'>" . htmlspecialchars($row['status']) . "</span></td>
                                <td>
                                    <a href='edit_user.php?id=" . $row['id'] . "'><i class='fas fa-edit text-primary'></i></a>
                                    <a href='delete_user.php?id=" . $row['id'] . "'><i class='fas fa-trash text-danger ms-2'></i></a>
                                </td>
                              </tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    
<!-- Add New User Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addUserModalLabel">Add New User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="userForm">
                    <div class="mb-3">
                        <label for="name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="role" class="form-label">Role</label>
                        <select class="form-select" id="role" name="role" required>
                            <option value="Admin">Admin</option>
                            <option value="HOD">HOD</option>
                            <option value="store">store</option>
                            <option value="lab assistant">lab assistant</option>
                            <option value="lab faculty incharge">lab faculty incharge</option>
                            <option value="purchase committee">purchase committee</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="lab" class="form-label">Lab</label>
                        <input type="text" class="form-control" id="lab" name="lab_name">
                    </div>
                    <div class="mb-3">
                        <!-- <label for="labId" class="form-label">Lab ID</label>
                        <input type="text" class="form-control" id="labId" name="labId"> -->
                        <label for="labId" class="form-label">Lab ID</label>
                        <select class="form-select" id="labId" name="labId" >
                            <option value="ADL">ADL</option>
                            <option value="CCL">CCL</option>
                            <option value="CGL">CGL</option>
                            <option value="FDL">FDL</option>
                            <option value="LXL">LXL</option>
                            <option value="NWL">NWL</option>
                            <option value="SSL">SSL</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Add User</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById("userForm").addEventListener("submit", function(event) {
        event.preventDefault();
        
        let formData = new FormData(this);

        fetch("add_user.php", {
            method: "POST",
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            alert(data); // Display response message
            location.reload(); // Refresh the page
        })
        .catch(error => console.error("Error:", error));
    });
</script>

    <script>
        document.getElementById("menu-toggle").addEventListener("click", function() {
         document.getElementById("dashboard-container").classList.toggle("collapsed");
        });
    </script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const links = document.querySelectorAll('.nav-link');
        
            // Get the last active link from localStorage
            const activeLink = localStorage.getItem('activeLink');
        
            if (activeLink) {
                // Remove active class from all links
                links.forEach(link => link.classList.remove('active'));
        
                // Add active class to the stored active link
                document.getElementById(activeLink)?.classList.add('active');
            } else {
                // If no stored active link, set Dashboard as default
                document.getElementById('dashboard-link').classList.add('active');
            }
        
            links.forEach(link => {
                link.addEventListener('click', function () {
                    // Remove active from all links
                    links.forEach(link => link.classList.remove('active'));
        
                    // Add active class to clicked link
                    this.classList.add('active');
        
                    // Store the clicked link's ID in localStorage
                    localStorage.setItem('activeLink', this.id);
                });
            });
        });
    </script>
             
</body>
</html>
