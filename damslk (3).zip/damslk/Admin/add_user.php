<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';  // Include PHPMailer if installed via Composer
include "db_config.php"; // Include database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $role = $_POST["role"];
    $lab_name = $_POST["lab_name"];
    $lab_id = $_POST["labId"];
    $plain_password = $_POST["password"]; // Use the password entered by the admin

    $hashed_password = password_hash($plain_password, PASSWORD_BCRYPT); // Hash password for storage


    // Insert user into the database
    $query = "INSERT INTO users (name, email, role, lab_name, lab_id, password, status) VALUES (?, ?, ?, ?, ?, ?, 'Active')";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ssssss", $name, $email, $role, $lab_name, $lab_id, $hashed_password);

    if (mysqli_stmt_execute($stmt)) {
        // Send email
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com'; // Gmail SMTP server
            $mail->SMTPAuth = true;
            $mail->Username = 'userexamp01@gmail.com'; // Your Gmail address
            $mail->Password = 'powl sptf difk rgkv'; // Your Gmail app password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption
            $mail->Port = 587; // TCP port to connect to
            // Email Headers
            $mail->setFrom('userexamp01@gmail.com', 'DAMS Support'); // Sender email and name
            $mail->addAddress($email); // Recipient email
            // Email Content
            $mail->isHTML(true);
            $mail->Subject = 'Welcome to DAMS - Your Account Details';
            $mail->Body = "
                <h3>Dear $name,</h3>
                <p>Your account has been successfully created on DAMS.</p>
                <p><strong>Email:</strong> $email</p>
                <p><strong>Password:</strong> <span style='color: blue;'>$plain_password</span></p>
                <p>Please change your password after logging in.</p>
                <br>
                <p>Best regards,<br>Admin Team</p>
            ";

            $mail->send();
            echo "User added successfully. Email sent!";
        } catch (Exception $e) {
            echo "User added but email not sent. Error: {$mail->ErrorInfo}";
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);
}
?>