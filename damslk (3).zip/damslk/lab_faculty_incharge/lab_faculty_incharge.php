<?php
session_start();
$host = "localhost";
$username = "root";
$password = "";
$dbname = "asset_management"; 

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure role matches "Lab Faculty Incharge"
$expectedRole = 'lab faculty incharge';

if (empty($_SESSION['role']) || strtolower(trim($_SESSION['role'])) !== strtolower($expectedRole)) {
    die("Access Denied! Role Mismatch.");
}

// Ensure lab_name is set in session
if (!isset($_SESSION['lab_name'])) {
    die("Access Denied! Lab Name Not Set.");
}

$lab_name= $_SESSION['lab_name'];

// Fetch forms assigned to Lab Incharge's lab (Pending status)
$sql = "SELECT * FROM requisitions WHERE lab_name = ? AND status = 'Pending lab incharge approval'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $lab_name);
$stmt->execute();
$result = $stmt->get_result();

if (!$result) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab Incharge Dashboard</title>
    <link rel="stylesheet" href="lab_faculty_incharge.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div id="dashboard-container" class="d-flex">
        <!-- Sidebar -->
        <div id="sidebar" class="d-flex flex-column p-3 text-white">
            <h4 class="mb-4">DAMS</h4>
            <ul class="nav nav-pills flex-column mb-auto">
                <li><a href="lab_faculty_incharge.php" class="nav-link text-white link-hover"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="../inventory/main.html" class="nav-link text-white link-hover"><i class="fas fa-box"></i> Inventory</a></li>
                <li><a href="../forms/proc.html" class="nav-link text-white link-hover"><i class="fas fa-file-alt"></i> Procurement</a></li>
                <li><a href="../maintenance/disposal.html" class="nav-link text-white link-hover"><i class="fas fa-exclamation-triangle"></i> Condemnation</a></li>
                <li><a href="../maintenance/maintenance_records.html" class="nav-link text-white link-hover"><i class="fas fa-wrench"></i> Maintenance</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div id="main-content" class="container-fluid p-4">
            <nav class="navbar navbar-light bg-custom d-flex justify-content-between">
                <button class="btn btn-dark ms-2" id="menu-toggle"><i class="fas fa-bars"></i></button>
                <input class="form-control w-50 ms-1" type="search" placeholder="Search assets...">
                <div>
                    <i class="fas fa-user fa-2x"></i>
                    <span class="ms-1 me-1"><b><?php echo htmlspecialchars($lab_name)?></span>
                </div>
            </nav>

            <h3 class="mt-4">Dashboard</h3>

            <div class="row my-4">
               
            </div>
            <div class="row my-4">    
                <div class="col-md-4"><a href="expertsel.php" class="text-decoration-none"><div class="d-flex justify-content-center btn btn-primary text-center p-3">Expert selection</div></a></div>
                <div class="col-md-4"><a href="#" class="text-decoration-none"><div class="d-flex justify-content-center btn btn-primary text-center p-3"> selected as expert</div></a></div>
                <div class="col-md-4"><a href="../Inventory/category.html" class="text-decoration-none"><div class="d-flex justify-content-center btn btn-primary text-center p-3"> Inventory</div></a></div>
            </div>

            <!-- Requisition Forms Table -->
            <div class="card p-3 mt-4">
                <h5>Pending Requisition Forms</h5>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Form ID</th>
                            <th>Lab Name</th>
                            <th>Specification</th>
                            <th>Quantity</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result->num_rows > 0) { ?>
                            <?php while ($row = $result->fetch_assoc()) { ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                                    <td><?php echo htmlspecialchars($row['lab_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['specification']); ?></td>
                                    <td><?php echo htmlspecialchars($row['quantity']); ?></td>
                                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                                    <td>
                                        <form action="../forms/approve_form.php" method="POST">
                                            <input type="hidden" name="id" value="<?php echo htmlspecialchars($row['id']); ?>">
                                            <button type="submit" class="btn btn-success">Approve</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php } ?>
                        <?php } else { ?>
                            <tr><td colspan="6" class="text-center">No pending requisitions.</td></tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>

            <div class="row mt-3">
                <div class="col-md-6">
                    <div class="card p-3">
                        <h5>Register Aprovals</h5>
                        <ul class="list-group">
                            <div id="notifications"></div>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card p-3">
                        <h5>Maintenance Alerts</h5>
                        <ul class="list-group">
                            <li class="list-group-item">PC maintenance pending</li>
                            <li class="list-group-item">Printer maintenance due 29/01/25</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.getElementById("menu-toggle").addEventListener("click", function() {
            document.getElementById("dashboard-container").classList.toggle("collapsed");
        });
    </script>
    <script>
        // function fetchNotifications(role) {
        //     fetch(`fetch_notifications.php?role=${role}`)
        //         .then(response => response.json())
        //         .then(data => {
        //             let notificationDiv = document.getElementById("notifications");
        //             notificationDiv.innerHTML = "";
        //             data.forEach(notification => {
        //                 let link = `<a href="approve.html?id=${notification.asset_id}" class="alert alert-info">${notification.message}</a>`;
        //                 notificationDiv.innerHTML += link;
        //             });
        //         });
        // }

        // // Call fetchNotifications with role 'LI' for Lab Incharge or 'HOD' for Head of Department
        // fetchNotifications('LI'); // or fetchNotifications('HOD');
        
    function fetchNotifications(role) {
        fetch(`fetch_notifications.php?role=${role}`)
            .then(response => response.json())
            .then(data => {
                let notificationDiv = document.getElementById("notifications");
                notificationDiv.innerHTML = ""; // Clear previous notifications

                if (data.length === 0) {
                    notificationDiv.innerHTML = "<p>No new notifications.</p>";
                    return;
                }

                let ul = document.createElement("ul"); // Create unordered list
                ul.classList.add("list-group"); // Bootstrap list style (optional)

                data.forEach(notification => {
                    let li = document.createElement("li"); // List item
                    li.classList.add("list-group-item"); // Bootstrap styling (optional)
                    
                    let link = document.createElement("a");
                    link.href = `approve.php?id=${notification.asset_id}`;
                    link.textContent = notification.message;
                    link.classList.add("alert", "alert-info", "d-block"); // Bootstrap styling (optional)

                    li.appendChild(link);
                    ul.appendChild(li);
                });

                notificationDiv.appendChild(ul);
            });
    }
    // console.log("Fetching notifications for role: LI");
    // Call fetchNotifications for Lab Incharge ('LI') or Head of Department ('HOD')
    fetchNotifications('LI');

</script>

<script>
  sessionStorage.setItem("firstPage", window.location.href);
</script>


</body>
</html>

<?php 
$stmt->close();
$conn->close(); 
?>