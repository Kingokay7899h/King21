<?php
include '../Inventory/db.php';

$asset_id = $_POST['asset_id'];
$role = $_POST['role']; // 'LI' or 'HOD'
$labId = $_POST['labId'];

if ($role == 'LI') {
    // Approve by Lab Incharge
    $stmt = $conn->prepare("UPDATE register SET li_sign = 1 WHERE sr_no = ?");
    $stmt->bind_param("i", $asset_id);
    $stmt->execute();

    // Remove LI notification
    $stmt = $conn->prepare("DELETE FROM notifications WHERE asset_id = ? AND role = 'LI'");
    $stmt->bind_param("i", $asset_id);
    $stmt->execute();

    // Notify HOD
    $message = "Asset ID $asset_id requires HOD approval.";
    $stmt = $conn->prepare("INSERT INTO notifications (asset_id, lab_id, role, message) VALUES (?, ?, 'HOD', ?)");
    $stmt->bind_param("iss", $asset_id, $labId, $message);
    $stmt->execute();

    echo "<script>alert('Approved successfully'); </script>";
    header("Location: " . ($role == 'LI' ? "lab_faculty_incharge.php" : "hod.html"));
    //    echo         "<script>
    //         let firstPage = sessionStorage.getItem("firstPage");
    //         if (firstPage) {
    //             window.location.href = firstPage; // Redirect to p1.html
    //         } else {
    //             window.location.href = document.referrer; // Default behavior (go to p2.html)
    //         }
    //         </script>"

}

if ($role == 'HOD') {
    // Approve by HOD
    $stmt = $conn->prepare("UPDATE register SET hod_sign = 1 WHERE sr_no = ?");
    $stmt->bind_param("i", $asset_id);
    $stmt->execute();

    // Remove HOD notification
    $stmt = $conn->prepare("DELETE FROM notifications WHERE asset_id = ? AND role = 'HOD'");
    $stmt->bind_param("i", $asset_id);
    $stmt->execute();

    echo "<script>alert('Approved successfully'); </script>";
    header("Location: " . ($role == 'LI' ? "lab_faculty_incharge.php" : "../Hod/hod.html"));
}

// header("Location: " . ($role == 'LI' ? "lab_faculty_incharge.html" : "hod.html"));
exit();
?>
