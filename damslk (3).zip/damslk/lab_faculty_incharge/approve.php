<?php
include '../Inventory/db.php';


$asset_id = $_GET['id'];
// var_dump($_GET['id']);

// Fetch asset details
$stmt = $conn->prepare("SELECT * FROM register WHERE sr_no = ?");
$stmt->bind_param("i", $asset_id);
$stmt->execute();
$result = $stmt->get_result();
$asset = $result->fetch_assoc();

if (!$asset) {
    echo "<p>Asset not found!</p>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approve Asset</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        table, th, td { border: 1px solid black; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .btn { padding: 10px 15px; text-decoration: none; cursor: pointer; }
        .approve-btn { background-color: green; color: white; border: none; }
    </style>
</head>
<body>

<h2>Register Asset Approval</h2>

<table>
    <tr><th>Field</th><th>Value</th></tr>
    <tr><td>Asset ID</td><td><?= $asset['sr_no'] ?></td></tr>
    <tr><td>Lab ID</td><td><?= $asset['lab_id'] ?></td></tr>
    <tr><td>Category ID</td><td><?= $asset['cid'] ?></td></tr>
    <tr><td>Asset Type</td><td><?= $asset['asset_type'] ?></td></tr>
    <tr><td>Item Name</td><td><?= $asset['name_of_the_item'] ?></td></tr>
    <tr><td>Entry Date</td><td><?= $asset['date'] ?></td></tr>
    <tr><td>Item Specification</td><td><?= $asset['item_specification'] ?></td></tr>
    <tr><td>Indent No.</td><td><?= $asset['indent_no'] ?></td></tr>
    <tr><td>Indent Date</td><td><?= $asset['indent_date'] ?></td></tr>
    <tr><td>Supplier</td><td><?= $asset['name_of_supplier'] ?></td></tr>
    <tr><td>Quantity</td><td><?= $asset['qty'] ?></td></tr>
    <tr><td>Bill No.</td><td><?= $asset['bill_no'] ?></td></tr>
    <tr><td>Bill Date</td><td><?= $asset['bill_date'] ?></td></tr>
    <tr><td>Price</td><td><?= $asset['price'] ?></td></tr>
    <tr><td>Used Quantity</td><td><?= $asset['used_qty'] ?></td></tr>
    <tr><td>Balance</td><td><?= $asset['balance_qty'] ?></td></tr>
    <tr><td>Lab Assistant Approval</td><td><?= $asset['la_sign'] ? 'Approved' : 'Pending' ?></td></tr>
    <tr><td>Lab Incharge Approval</td><td><?= $asset['li_sign'] ? 'Approved' : 'Pending' ?></td></tr>
    <tr><td>HOD Approval</td><td><?= $asset['hod_sign'] ? 'Approved' : 'Pending' ?></td></tr>
</table>

<form action="approve_asset.php" method="POST">
    <input type="hidden" name="asset_id" value="<?= $asset_id ?>">
    <input type="hidden" name="labId" value="<?= $asset['lab_id'] ?>">

    <?php if ($asset['li_sign'] == 0): ?>
        <button type="submit" name="role" value="LI" class="btn approve-btn">Approve as Lab Incharge</button>
    <?php elseif ($asset['hod_sign'] == 0): ?>
        <button type="submit" name="role" value="HOD" class="btn approve-btn">Approve as HOD</button>
    <?php else: ?>
        <p>✅ This asset has been fully approved.</p>
    <?php endif; ?>
</form>

</body>
</html>
