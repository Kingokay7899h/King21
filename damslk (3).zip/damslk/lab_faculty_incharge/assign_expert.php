<?php
session_start();
include '../Admin/db_config.php';
require '../forms/phpmailer-master/src/PHPMailer.php';
require '../forms/phpmailer-master/src/SMTP.php';
require '../forms/phpmailer-master/src/Exception.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendApprovalEmail($to, $subject, $message) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'rigvednk10@gmail.com';
        $mail->Password = 'kdpi qkuk rypu fvtj';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('rigvednk10@gmail.com', 'Asset Management System');
        $mail->addAddress($to);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $message;

        return $mail->send();
    } catch (Exception $e) {
        error_log("Email Error: " . $mail->ErrorInfo);
        return false;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $requisition_id = $_POST['requisition_id'];
    $expert_email = $_POST['expert'];

    $query = "UPDATE requisitions SET expert_email = ?, status = 'Pending Expert Approval' WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "si", $expert_email, $requisition_id);

    if (mysqli_stmt_execute($stmt)) {
        $subject = "New Requisition Assigned";
        $message = "Dear Expert, a new requisition has been assigned to you.";
        sendApprovalEmail($expert_email, $subject, $message);
        echo "<script>alert('Expert assigned successfully!'); window.location.href = 'lab_faculty_incharge.php';</script>";
    } else {
        echo "<script>alert('Error assigning expert!'); window.history.back();</script>";
    }
    mysqli_stmt_close($stmt);
}

mysqli_close($conn);
?>
