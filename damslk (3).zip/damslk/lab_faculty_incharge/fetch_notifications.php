<?php
session_start();
include '../Inventory/db.php';
// var_dump($_GET);
// $role = $_GET['role']; // 'LI' or 'HOD'
$role = $_GET['role'] ?? null;
if (!$role) {
    die(json_encode(["error" => "Role parameter is missing"]));
}
$lab_id = $_SESSION['lab_id']; // Get from session or request

if($role=='LI')
{
    $stmt = $conn->prepare("SELECT id, asset_id, message FROM notifications WHERE role = ? AND lab_id = ? AND is_read = 0");
    $stmt->bind_param("ss", $role, $lab_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $notifications = [];
}
else{
    $stmt = $conn->prepare("SELECT id, asset_id, message FROM notifications WHERE role = ?  AND is_read = 0");
    $stmt->bind_param("s", $role);
    $stmt->execute();
    $result = $stmt->get_result();
    $notifications = [];
}


while ($row = $result->fetch_assoc()) {
    $notifications[] = $row;
}
// var_dump($notifications);

echo json_encode($notifications);
?>
