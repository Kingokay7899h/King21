<?php
session_start();

echo "Role: " . ($_SESSION['role'] ?? 'Not Set') . "<br>";
echo "Email: " . ($_SESSION['email'] ?? 'Not Set') . "<br>";

include '../Admin/db_config.php';

// Ensure only Lab Faculty Incharges can access this page
if (!isset($_SESSION['email']) || strtolower($_SESSION['role']) !== 'lab faculty incharge') {
    die("Unauthorized access!");
}

$email = $_SESSION['email'];

// Get the lab name where the logged-in user is the Lab Incharge
$lab_query = "SELECT lab_name FROM users WHERE email = ?";
$lab_stmt = mysqli_prepare($conn, $lab_query);
mysqli_stmt_bind_param($lab_stmt, "s", $email);
mysqli_stmt_execute($lab_stmt);
$lab_result = mysqli_stmt_get_result($lab_stmt);
$lab_row = mysqli_fetch_assoc($lab_result);
$lab_name = $lab_row['lab_name'] ?? null; // Get the lab name

if ($lab_name) {
    // Fetch pending requisitions assigned to this Lab Incharge's lab
    $req_query = "SELECT id FROM requisitions WHERE lab_name = ? AND status = 'Pending Expert Approval'";
    $stmt = mysqli_prepare($conn, $req_query);
    mysqli_stmt_bind_param($stmt, "s", $lab_name);
    mysqli_stmt_execute($stmt);
    $req_result = mysqli_stmt_get_result($stmt);
} else {
    die("Lab not found for the logged-in user.");
}

// Fetch Lab Faculty Incharges (Experts), excluding the logged-in Lab Incharge
$expert_query = "SELECT email, name FROM users WHERE role = 'Lab Faculty Incharge' AND email != ?";
$expert_stmt = mysqli_prepare($conn, $expert_query);
mysqli_stmt_bind_param($expert_stmt, "s", $email);
mysqli_stmt_execute($expert_stmt);
$expert_result = mysqli_stmt_get_result($expert_stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expert Selection</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background-color: #f8f9fa; padding: 20px; }
        .container { width: 100%; max-width: 100%; min-height: 100vh; display: flex; flex-direction: column; }
        .dashboard { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); width: 100%; }
        .header { font-size: 24px; font-weight: bold; margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; }
        label { font-weight: bold; }
        select, input { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px; }
        .submit-btn { background: blue; color: white; padding: 10px 15px; border: none; border-radius: 5px; cursor: pointer; }
        .submit-btn:hover { background: darkblue; }
    </style>
</head>
<body>
    <div class="container">
        <div class="dashboard">
            <div class="header">Expert Selection</div>
            <form action="assign_expert.php" method="POST">
                <div class="form-group">
                    <label for="requisition_id">Select Requisition:</label>
                    <select name="requisition_id" id="requisition_id" required>
                        <option value="">-- Select Requisition --</option>
                        <?php while ($row = mysqli_fetch_assoc($req_result)) { ?>
                            <option value="<?= htmlspecialchars($row['id']) ?>"><?= htmlspecialchars($row['id']) ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="expert">Select Expert:</label>
                    <select name="expert" id="expert" required>
                        <option value="">-- Select Expert --</option>
                        <?php while ($row = mysqli_fetch_assoc($expert_result)) { ?>
                            <option value="<?= htmlspecialchars($row['email']) ?>"><?= htmlspecialchars($row['name']) ?></option>
                        <?php } ?>
                    </select>
                </div>
                <button type="submit" class="submit-btn">Assign Expert</button>
            </form>
        </div>
    </div>
</body>
</html>
