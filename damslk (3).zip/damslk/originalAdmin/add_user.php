<?php
include "db_config.php";

$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$role = $_POST['role'] ?? '';
$lab = $_POST['lab'] ?? '';
$password = $_POST['password'] ?? '';

if ($password) {
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
} else {
    die("Password is required!");
}

// Prepared statement to prevent SQL injection
$sql = "INSERT INTO users (name, email, role, lab, password) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssss", $name, $email, $role, $lab, $hashed_password);

if ($stmt->execute()) {
    echo "User added successfully!";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
