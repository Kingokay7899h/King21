<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="admin.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div id="dashboard-container" class="d-flex">
        <!-- Sidebar -->
        <div id="sidebar" class="d-flex flex-column p-3 text-white">
            <h4 class="mb-4">DAMS</h4>
            <ul class="nav nav-pills flex-column mb-auto">
                <li><a href="admin.html" class="nav-link text-white link-hover "><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="user_manage.html" class="nav-link text-white link-hover"><i class="fas fa-users"></i> User Management</a></li>
                <li><a href="#" class="nav-link text-white link-hover"><i class="fas fa-box"></i> Inventory</a></li>
                <li><a href="#" class="nav-link text-white link-hover"><i class="fas fa-file-alt"></i> Requisition</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div id="main-content" class="container-fluid p-4">
            
            <nav class="navbar navbar-light bg-custom d-flex justify-content-between">
                <button class="btn btn-dark ms-2" id="menu-toggle"><i class="fas fa-bars"></i></button>
                <input class="form-control w-50 ms-1" type="search" placeholder="Search assets...">
                <div>
                    <i class="fas fa-user fa-2x"></i>
                    <span class="ms-1 me-1"><b>Flyod Vaz (Admin)</b></span>
                </div>
            </nav>
            <h3 class="mt-4">User Management</h3>
            <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addUserModal"><i class="fas fa-user-plus"></i> Add New User</button>

            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr> 
                </thead>
                <tbody>
                        <?php
                        include "db_config.php"; 
                    
                        $query = "SELECT * FROM users";
                        $result = mysqli_query($conn, $query);
                    
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>
                                    <td><i class='fas fa-user'></i> " . htmlspecialchars($row['name']) . "</td>
                                    <td>" . htmlspecialchars($row['email']) . "</td>
                                    <td>" . htmlspecialchars($row['role']) . "</td>
                                    <td><span class='badge " . ($row['status'] == 'Active' ? 'bg-success' : 'bg-danger') . "'>" . htmlspecialchars($row['status']) . "</span></td>
                                    <td>
                                        <a href='edit_user.php?id=" . $row['id'] . "'><i class='fas fa-edit text-primary'></i></a>
                                        <a href='delete_user.php?id=" . $row['id'] . "'><i class='fas fa-trash text-danger ms-2'></i></a>
                                    </td>
                                  </tr>";
                        }
                        ?>
                    </tbody>
            </table>
        </div>
    </div>

    
<!-- Add New User Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addUserModalLabel">Add New User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="userForm" action="add_user.php" method="post">
                    <div class="mb-3">
                        <label for="name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="role" class="form-label">Role</label>
                        <select class="form-select" id="role" name="role" required>
                            <option value="Admin">Admin</option>
                            <option value="HOD">HOD</option>
                            <option value="store">store</option>
                            <option value="lab assistant">lab assistant</option>
                            <option value="lab faculty incharge">lab faculty incharge</option>
                            <option value="purchase committee">purchase committee</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="lab" class="form-label">Lab</label>
                        <input type="text" class="form-control" id="lab" name="lab">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Add User</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById("userForm").addEventListener("submit", function(event) {
        event.preventDefault();
        
        let formData = new FormData(this);

        fetch("add_user.php", {
            method: "POST",
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            alert(data); // Display response message
            location.reload(); // Refresh the page
        })
        .catch(error => console.error("Error:", error));
    });
</script>

    <script>
        document.getElementById("menu-toggle").addEventListener("click", function() {
         document.getElementById("dashboard-container").classList.toggle("collapsed");
        });
    </script>
</body>
</html>
