<?php
include '../Admin/db_config.php';

// Fetch forms pending committee approval
$sql = "SELECT * FROM requisitions WHERE status = 'sent to committee'";
$result = mysqli_query($conn, $sql);

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>
            <td>" . $row['id'] . "</td>
            <td>" . $row['lab_name'] . "</td>
            <td>" . $row['storesInward'] . "</td>
            <td>" . $row['department'] . "</td>
            <td>" . $row['date'] . "</td>
            <td>" . $row['specification'] . "</td>
            <td>" . $row['fund'] . "</td>
            <td>" . $row['previous_purchase'] . "</td>
            <td>" . $row['justification'] . "</td>
            <td>" . $row['quantity'] . "</td>
            <td>" . $row['cost'] . "</td>
            <td>" . $row['suppliers'] . "</td>
            <td>
                <form method='POST' action='princiapp.php'>
                    <input type='hidden' name='form_id' value='" . $row['id'] . "'>
                    <button type='submit' name='approve'>Approve</button>
                    <button type='button' onclick='showRejectModal(" . $row['id'] . ")'>Reject</button>
                </form>
            </td>
          </tr>";
}

mysqli_close($conn);
?>
