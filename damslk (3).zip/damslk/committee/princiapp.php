<?php
include '../Admin/db_config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $form_id = $_POST['form_id'];

    if (isset($_POST['approve'])) {
        $status = "Approved by Committee";
        $query = "UPDATE requisitions SET status='$status' WHERE id=$form_id";
        mysqli_query($conn, $query);
    } elseif (isset($_POST['reject'])) {
        $status = "Rejected by Committee";
        $comment = mysqli_real_escape_string($conn, $_POST['comment']);
        $query = "UPDATE requisitions SET status='$status', rejection_comment='$comment' WHERE id=$form_id";
        mysqli_query($conn, $query);
    }
    header("Location: req25k.php");
}
?>
