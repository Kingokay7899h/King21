<?php
session_start();
include '../Authetication/db_config.php'; // Ensure this file includes your database connection setup

// Check if user is logged in and has a lab assigned
if (!isset($_SESSION['lab_name'])) {
    die("Access denied. Lab not assigned.");
}

$lab_name = $_SESSION['lab_name'];

$query = "SELECT * FROM requisitions WHERE lab_name = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $lab_name);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>lab assistant Dashboard</title>
    <link rel="stylesheet" href="new_lab_assistant.css">
    <!-- <link rel="stylesheet" href="/status_bar.css"> -->
    <!-- <script src="status_bar.js"></script> -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div id="dashboard-container" class="d-flex">
        <!-- Sidebar -->
        <div id="sidebar" class="d-flex flex-column   py-3 ">
            <h4 class="dams ps-4 pt-4 mb-5"><b>DAMS</b></h4>
            <ul class="nav nav-pills flex-column mb-auto">
                <li><a href="lab_assistant.php" class="nav-link link-hover" id="dashboard-link"><i class="fas fa-home pe-2 ps-2"></i> Dashboard</a></li>
                <li><a href="../Inventory/category.html" class="nav-link link-hover" id="inventory-link"><i class="fas fa-box pe-2 ps-2"></i> Inventory</a></li>
                <li><a href="../forms/proc.html" class="nav-link link-hover" id="requisition-link"><i class="fas fa-file-alt pe-2 ps-2"></i> Procurement</a></li>
                <li><a href="#" class="nav-link link-hover" id="condemnation-link"><i class="fas fa-exclamation-triangle pe-2 ps-2"></i> Codemnation</a></li>
                <li><a href="#" class="nav-link link-hover" id="maintenance-link"><i class="fas fa-wrench pe-2 ps-2"></i> Maintenance</a></li>
            </ul>

            <!-- <a href="sign_in.html" class="nav-link link-hover mt-auto ms-3 mb-4">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a> -->
        </div>

        
        <!-- Main Content -->
        <div id="main-content" class="container-fluid">
            <div class="row mynav d-flex">
                <nav class="navbar w-100 navbar-light bg-custom d-flex justify-content-between">
                    <span class="ms-3" id="menu-toggle"><i class="fas fa-bars"></i></span>
                    <input class="form-control w-50 ms-1" type="search" placeholder="Search assets...">
                    <div>
                        <i class="far fa-user"></i>
                        <span class="ms-1 me-3"><?php echo $_SESSION['name']; ?> (Lab Assistant)</span>
                    </div>
                </nav>
            </div>
            <h3 class="mt-4">Dashboard</h3>
            <div class="row my-4">
                <div class="col-md-6">
                    <a href="../Inventory/category.html"  class="text-decoration-none">
                        <div class="d-flex btn btn-primary rounded shadow justify-content-center text-center p-3" >Inventory</div>
                    </a>
                </div>
                <div class="col-md-6">
                    <a href="user_manage.php" class="text-decoration-none">
                        <div class="d-flex btn btn-primary rounded shadow justify-content-center text-center p-3">Maintenance</div>
                    </a>
                </div>
            </div>
            <div class="row my-4">
                <div class="col-md-6">
                    <a href="../forms/proc.html" class="text-decoration-none">
                        <div class="d-flex justify-content-center btn btn-primary rounded shadow text-center p-3">Procurement</div>
                    </a>
                </div>
                <div class="col-md-6">
                    <a href="#" class="text-decoration-none">
                        <div class="d-flex justify-content-center btn btn-primary rounded shadow text-center p-3">Condemnation Form</div>
                    </a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card p-3">
                        <h5>Requisitions for <?php echo $lab_name; ?></h5>
                        <ul class="list-group">
                            <?php while ($row = $result->fetch_assoc()) { ?>
                                <li class="list-group-item">Requisition #<?php echo $row['id']; ?> - <?php echo $row['status']; ?></li>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

    <script>
        document.getElementById("menu-toggle").addEventListener("click", function() {
         document.getElementById("dashboard-container").classList.toggle("collapsed");
        });
    </script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const links = document.querySelectorAll('.nav-link');
        
            // Get the last active link from localStorage
            const activeLink = localStorage.getItem('activeLink');
        
            if (activeLink) {
                // Remove active class from all links
                links.forEach(link => link.classList.remove('active'));
        
                // Add active class to the stored active link
                document.getElementById(activeLink)?.classList.add('active');
            } else {
                // If no stored active link, set Dashboard as default
                document.getElementById('dashboard-link').classList.add('active');
            }
        
            links.forEach(link => {
                link.addEventListener('click', function () {
                    // Remove active from all links
                    links.forEach(link => link.classList.remove('active'));
        
                    // Add active class to clicked link
                    this.classList.add('active');
        
                    // Store the clicked link's ID in localStorage
                    localStorage.setItem('activeLink', this.id);
                });
            });
        });
    </script>
     <script>
        
const one =document.querySelector(".one");
const two =document.querySelector(".two");
const three =document.querySelector(".three");
const four =document.querySelector(".four");
const five =document.querySelector(".five");
const six =document.querySelector(".six");

one.onclick =function(){
    one.classList.add("active");
    two.classList.remove("active");
    three.classList.remove("active");
    four.classList.remove("active");
    five.classList.remove("active");
    six.classList.remove("active");
}

two.onclick =function(){
    one.classList.add("active");
    two.classList.add("active");
    three.classList.remove("active");
    four.classList.remove("active");
    five.classList.remove("active");
    six.classList.remove("active");

}

three.onclick =function(){
    one.classList.add("active");
    two.classList.add("active");
    three.classList.add("active");
    four.classList.remove("active");
    five.classList.remove("active");
    six.classList.remove("active");
}

four.onclick =function(){
    one.classList.add("active");
    two.classList.add("active");
    three.classList.add("active");
    four.classList.add("active");
    five.classList.remove("active");
    six.classList.remove("active");
}

five.onclick =function(){
    one.classList.add("active");
    two.classList.add("active");
    three.classList.add("active");
    four.classList.add("active");
    five.classList.add("active");
    six.classList.remove("active");
}

six.onclick =function(){
    one.classList.add("active");
    two.classList.add("active");
    three.classList.add("active");
    four.classList.add("active");
    five.classList.add("active");
    six.classList.add("active");
}

     </script>

<script>
    function redirectToDetails(url) {
        window.location.href = url;
    }
</script>

 </body>
</html>
