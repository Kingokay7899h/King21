// Add this JavaScript to your existing script

// Edit Issue Modal Logic (for Student Issues)
const editButtons = document.querySelectorAll(".edit-btn");
const modal = document.createElement("div");
modal.classList.add("modal");

modal.innerHTML = `
    <div class="modal-content">
        <div class="modal-header">
            <h3>Edit Issue</h3>
            <span class="close-modal">&times;</span>
        </div>
        <div class="modal-body">
            <label for="issue-status">Status</label>
            <select id="issue-status">
                <option value="Pending">Pending</option>
                <option value="Resolved">Resolved</option>
            </select>
            <label for="issue-details">Issue Details</label>
            <textarea id="issue-details" rows="4"></textarea>
        </div>
        <div class="modal-footer">
            <button class="cancel-btn">Cancel</button>
            <button class="save-btn">Save</button>
        </div>
    </div>
`;

document.body.appendChild(modal);

// Open Modal (for Student Issues)
editButtons.forEach(button => {
    button.addEventListener("click", function () {
        modal.style.display = "flex";
    });
});

// Close Modal (for Student Issues)
modal.querySelector(".close-modal").addEventListener("click", function () {
    modal.style.display = "none";
});

modal.querySelector(".cancel-btn").addEventListener("click", function () {
    modal.style.display = "none";
});

// Save Changes (for Student Issues)
modal.querySelector(".save-btn").addEventListener("click", function () {
    const status = modal.querySelector("#issue-status").value;
    const details = modal.querySelector("#issue-details").value;

    // Update the table row
    const row = document.querySelector(".edit-btn").closest("tr");
    row.querySelector("td:nth-child(5)").textContent = status;
    row.querySelector("td:nth-child(4)").textContent = details;

    modal.style.display = "none";
    showToast("Issue updated successfully!");
});

// Edit Modal Logic for Maintenance Records
const editModal = document.getElementById("editModal");
const editForm = document.getElementById("editForm");

function openEditModal(rowIndex) {
    const row = document.querySelector(`table tbody tr:nth-child(${rowIndex})`);
    const labName = row.querySelector("td:nth-child(3)").textContent;
    const productName = row.querySelector("td:nth-child(4)").textContent;
    const purchaseDate = row.querySelector("td:nth-child(5)").textContent;
    const serviceProvider = row.querySelector("td:nth-child(6)").textContent;
    const dueDate = row.querySelector("td:nth-child(7)").textContent;
    const lastMaintenance = row.querySelector("td:nth-child(8)").textContent;

    // Populate the modal form
    document.getElementById("labName").value = labName;
    document.getElementById("productName").value = productName;
    document.getElementById("purchaseDate").value = purchaseDate;
    document.getElementById("serviceProvider").value = serviceProvider;
    document.getElementById("lastMaintenance").value = lastMaintenance;

    // Store the row index in the form dataset
    editForm.dataset.rowIndex = rowIndex;

    // Show the modal
    editModal.style.display = "block";
}

function closeEditModal() {
    editModal.style.display = "none";
}

// Handle form submission (for Maintenance Records)
editForm.addEventListener("submit", function (e) {
    e.preventDefault();

    const lastMaintenanceDate = document.getElementById("lastMaintenance").value;
    const purchaseDate = document.getElementById("purchaseDate").value;

    // Calculate new due date (10 years after purchase date)
    const purchaseDateObj = new Date(purchaseDate);
    const dueDateObj = new Date(purchaseDateObj.setFullYear(purchaseDateObj.getFullYear() + 10));
    const dueDate = dueDateObj.toISOString().split("T")[0];

    // Update the table row
    const row = document.querySelector(`table tbody tr:nth-child(${editForm.dataset.rowIndex})`);
    row.querySelector("td:nth-child(8)").textContent = lastMaintenanceDate;
    row.querySelector("td:nth-child(7)").textContent = dueDate;

    // Close the modal
    closeEditModal();
    showToast("Maintenance record updated successfully!");
});

// Disposal Request Logic
function sendDisposalRequest() {
    const selectedRows = document.querySelectorAll(".rowCheckbox:checked");

    if (selectedRows.length === 0) {
        showToast("Please select at least one item for disposal.");
        return;
    }

    selectedRows.forEach(row => {
        const rowData = row.closest("tr");
        const labName = rowData.querySelector("td:nth-child(3)").textContent;
        const productName = rowData.querySelector("td:nth-child(4)").textContent;

        // Add to disposal table
        const disposalTableBody = document.getElementById("disposalTableBody");
        const newRow = document.createElement("tr");
        newRow.innerHTML = `
            <td>${disposalTableBody.children.length + 1}</td>
            <td>${labName}</td>
            <td>${productName}</td>
            <td>Obsolete</td>
            <td>Pending</td>
        `;
        disposalTableBody.appendChild(newRow);

        // Send email using SendGrid API
        sendEmail(labName, productName);
    });

    showToast("Disposal request sent successfully!");
}

// Send Email using SendGrid API
async function sendEmail(labName, productName) {
    const emailContent = {
        to: "itsmytimefromnow@gmail.com", // Recipient email
        from: "shreyashdesai60@gmail.com", // Replace with your verified sender email
        subject: "Disposal Request Approval",
        html: `
            <div style="font-family: Arial, sans-serif; color: #333; text-align: center;">
                <h2 style="color: #4A90E2;">Disposal Request Approval</h2>
                <p>Dear Sir,</p>
                <p>You have received a condemnation request approval for the following item:</p>
                <p><strong>Lab Name:</strong> ${labName}</p>
                <p><strong>Product Name:</strong> ${productName}</p>
                <p>Please check your dashboard for further details.</p>
                <p style="color: #6C5CE7;">Thank you!</p>
            </div>
        `,
    };

    try {
        const response = await fetch("https://api.sendgrid.com/v3/mail/send", {
            method: "POST",
            headers: {
                "Authorization": `Bearer SG. 3Ox-Tu1_SaaNKKnC97HZ2g.tRR7ZGVfYWYCF1RV_J3y6ZuudfeuIcrq1R_6SWvnX4g`, // Replace with your SendGrid API key
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                personalizations: [{ to: [{ email: emailContent.to }] }],
                from: { email: emailContent.from },
                subject: emailContent.subject,
                content: [{ type: "text/html", value: emailContent.html }],
            }),
        });

        if (response.ok) {
            console.log("Email sent successfully!");
            showToast("Email sent to itsmytimefromnow@gmail.com");
        } else {
            console.error("Failed to send email:", await response.text());
            showToast("Failed to send email.");
        }
    } catch (error) {
        console.error("Error sending email:", error);
        showToast("Error sending email.");
    }
}

// Toast Notification Logic
function showToast(message) {
    const toast = document.getElementById("toast");
    toast.textContent = message;
    toast.classList.add("show");
    setTimeout(() => toast.classList.remove("show"), 3000);
}
