<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "asset_management";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = isset($_SESSION['lab_name']) ? $_SESSION['lab_name'] : '';
$user_role = isset($_SESSION['role']) ? $_SESSION['role'] : 'Guest';
$user_email = isset($_SESSION['user']) ? $_SESSION['user'] : '';

// Fetch pending requisitions for approval
$sql = "SELECT * FROM requisitions WHERE status IN ('Pending Lab Incharge Approval', 'Pending Expert Approval', 'Pending HOD Approval')";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approval Dashboard</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <h2>Pending Approvals for <?php echo htmlspecialchars($user_role); ?></h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Lab Name</th>
            <th>Department</th>
            <th>Specification</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr id="row-<?php echo $row['id']; ?>">
                <td><?php echo htmlspecialchars($row['id']); ?></td>
                <td><?php echo htmlspecialchars($row['lab_name']); ?></td>
                <td><?php echo htmlspecialchars($row['department']); ?></td>
                <td><?php echo htmlspecialchars($row['specification']); ?></td>
                <td id="status-<?php echo $row['id']; ?>">
                    <?php echo htmlspecialchars($row['status']); ?>
                </td>
                <td>
                    <?php if ($user_role == "lab faculty incharge" && $row['status'] == "Pending Lab Incharge Approval") { ?>
                        <form action="assign_expert.php" method="POST">
                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                            <button type="submit">Assign Expert</button>
                        </form>
                    <?php } elseif ($user_role == "lab faculty incharge" && $row['status'] == "Pending Expert Approval") { ?>
                        <!-- Lab Incharge should not see approval button at Expert Approval stage -->
                    <?php } elseif ($user_role == "HOD" && $row['status'] == "Pending HOD Approval") { ?>
                        <button class="approve-btn" data-id="<?php echo $row['id']; ?>">Approve</button>
                    <?php } elseif ($user_role == "lab faculty incharge" && $row['expert_email'] == $user_email && $row['status'] == "Pending Expert Approval") { ?>
                        <!-- Assigned Expert should see the Approve button -->
                        <button class="approve-btn" data-id="<?php echo $row['id']; ?>">Approve</button>
                    <?php } ?>
                </td>
            </tr>
        <?php } ?>
    </table>

    <script>
    $(document).ready(function () {
        $(".approve-btn").click(function (event) {
            event.preventDefault(); // Prevent default button action (important)
            var id = $(this).data("id");
            var button = $(this);

            $.ajax({
                url: "approve_form.php",
                type: "POST",
                data: { id: id },
                success: function (response) {
                    if (response.trim() === "success") {
                        $("#row-" + id).fadeOut(300, function () { 
                            $(this).remove(); 
                        }); // Remove row after approval
                    } else {
                        alert("Approval failed! Error: " + response);
                    }
                },
                error: function () {
                    alert("Error processing request.");
                }
            });
        });
    });
    </script>
</body>
</html>

<?php
$conn->close();
?>
