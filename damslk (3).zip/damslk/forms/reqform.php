<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'phpmailer-master/src/PHPMailer.php';
require 'phpmailer-master/src/SMTP.php';
require 'phpmailer-master/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "asset_management";

// Database Connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Required fields
    $required_fields = ['lab_name', 'department', 'date', 'specification', 'fund', 'justification', 'quantity', 'cost', 'suppliers'];

    $missing_fields = [];
    foreach ($required_fields as $field) {
        if (!isset($_POST[$field]) || empty(trim($_POST[$field]))) {
            $missing_fields[] = $field;
        }
    }

    if (!empty($missing_fields)) {
        die(json_encode(["status" => "error", "message" => "Missing fields", "missing_fields" => $missing_fields]));
    }

    // Validate numeric fields
    if (!is_numeric($_POST['quantity']) || !is_numeric($_POST['cost'])) {
        die(json_encode(["status" => "error", "message" => "Quantity and Cost must be numbers"]));
    }

    // Assign values
    $lab_name = $_POST['lab_name'];
    $storesInward = !empty($_POST['storesInward']) ? $_POST['storesInward'] : NULL;
    $department = $_POST['department'];
    $date = $_POST['date'];
    $specification = $_POST['specification'];
    $fund = $_POST['fund'];
    $previous_purchase = !empty($_POST['previous_purchase']) ? $_POST['previous_purchase'] : NULL;
    $justification = $_POST['justification'];
    $quantity = $_POST['quantity'];
    $cost = $_POST['cost'];
    $suppliers = $_POST['suppliers'];
    $status = "Pending Lab Incharge Approval";

    // Insert into database
    $sql = "INSERT INTO requisitions (lab_name, storesInward, department, date, specification, fund, previous_purchase, justification, quantity, cost, suppliers, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssssss", $lab_name, $storesInward, $department, $date, $specification, $fund, $previous_purchase, $justification, $quantity, $cost, $suppliers, $status);

    if ($stmt->execute()) {
        $last_id = $stmt->insert_id;  // Get the last inserted ID

        // Fetch Lab Faculty Incharge Email based on lab_name
        $query = "SELECT email FROM users WHERE role='Lab faculty incharge' AND lab_name=?";
        $stmt2 = $conn->prepare($query);
        $stmt2->bind_param("s", $lab_name);
        $stmt2->execute();
        $result = $stmt2->get_result();

        if ($result->num_rows > 0) {
            $lab_incharge = $result->fetch_assoc();
            $to = $lab_incharge['email'];

            if (!empty($to)) {
                $subject = "New Purchase Requisition Approval Required";
                $message = "A new purchase requisition form (ID: $last_id) is waiting for your approval in the dashboard.";

                // Send Email
                if (!sendApprovalEmail($to, $subject, $message)) {
                    echo json_encode(["status" => "warning", "message" => "Requisition submitted but email sending failed"]);
                } else {
                    echo json_encode(["status" => "success", "message" => "Requisition submitted & email sent to $to"]);
                }
            } else {
                echo json_encode(["status" => "warning", "message" => "Requisition submitted but no Lab Faculty Incharge email found"]);
            }
        } else {
            echo json_encode(["status" => "warning", "message" => "Requisition submitted but no Lab Faculty Incharge found"]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Database insert failed", "error" => $stmt->error]);
    }

    // Close Statements & Connection
    $stmt->close();
    $stmt2->close();
    $conn->close();
}

// Function to send email using PHPMailer
function sendApprovalEmail($to, $subject, $message) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'rigvednk10@gmail.com';
        $mail->Password = 'kdpi qkuk rypu fvtj';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('rigvednk10@gmail.com', 'Asset Management System');
        $mail->addAddress($to);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $message;

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("PHPMailer Error: " . $mail->ErrorInfo);
        return false;
    }
}

?>
