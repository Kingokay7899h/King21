<?php
session_start();
if (isset($_SESSION['email'])) {
    echo "Session Email: " . $_SESSION['email'] . "<br>";
    echo "Session Role: " . $_SESSION['role'];
} else {
    echo "Session not set!";
}
?>
