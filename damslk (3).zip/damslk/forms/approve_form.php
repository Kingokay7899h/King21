<?php
session_start();

$lab_incharge_lab = $_SESSION['lab_name'];

require 'phpmailer-master/src/PHPMailer.php';
require 'phpmailer-master/src/SMTP.php';
require 'phpmailer-master/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "asset_management";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if request is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];

    // Fetch HOD email from users table
    $stmt = $conn->prepare("SELECT email FROM users WHERE role = 'HOD'");
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $hod_email = $result['email'];

    // Update status in database
    $next_status = "Pending HOD Approval";
    $stmt = $conn->prepare("UPDATE requisitions SET status = ? WHERE id = ?");
    $stmt->bind_param("ss", $next_status, $id);
    $stmt->execute();

    // Send email to HOD
    if (!empty($hod_email)) {
        $subject = "Purchase Requisition Needs Your Approval";
        $message = "Requisition ID $id is waiting for your approval in the dashboard.";
        sendApprovalEmail($hod_email, $subject, $message);
    }

    header("Location: ../lab_faculty_incharge/lab_faculty_incharge.php?lab=" . $lab_incharge_lab);
    exit();
}
$conn->close();

// Email Function
function sendApprovalEmail($to, $subject, $message) {
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'rigvednk10@gmail.com';
        $mail->Password = 'kdpi qkuk rypu fvtj';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('rigvednk10@gmail.com', 'Asset Management System');
        $mail->addAddress($to);

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $message;

        $mail->send();
        return true;
    } catch (Exception $e) {
        return "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
