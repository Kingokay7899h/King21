<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Forms</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            border: 1px solid #000;
            padding: 20px;
        }

        .header {
            text-align: center;
            font-size: 22px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .fields {
            overflow: hidden;
            margin-bottom: 20px;
        }

        .field-left {
            float: left;
            margin-right: 20px;
        }

        .field-right {
            float: right;
        }

        .field-label {
            display: inline-block;
            width: 50px;
            font-weight: bold;
            margin-right: 5px;
        }

        .field-input {
            display: inline-block;
            vertical-align: top;
        }

        .long-underline {
            border: none;
            width: 120px;
            font-family: Arial, sans-serif;
            font-size: 14px;
            outline: none;
            border-bottom: 1px solid #000 !important;
            background: none;
            padding: 0;
            box-sizing: border-box;
            display: inline-block;
            margin-left: 5px;
        }

        input[type="date"] {
            border: none;
            width: 120px;
            font-family: Arial, sans-serif;
            font-size: 14px;
            outline: none;
            border-bottom: 1px solid #000 !important;
            background: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
        }

        input[type="text"].long-underline {
            border-bottom: 1px solid #000 !important;
        }

        input[type="text"] {
            border: none;
            width: 100%;
            font-family: Arial, sans-serif;
            font-size: 14px;
            outline: none;
            background: none;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #000;
            padding: 20px;
            text-align: left;
        }

        .notes {
            margin-top: 20px;
            font-size: 14px;
        }

        .nav-button {
            padding: 8px 15px;
            font-size: 14px;
            cursor: pointer;
            background-color: #f0f0f0;
            border: 1px solid #000;
            border-radius: 4px;
            text-align: center;
            display: block;
            margin-top: 10px;
        }

        .nav-button:hover {
            background-color: #e0e0e0;
        }

        th[colspan] {
            text-align: center;
        }

        .single-line-label {
            white-space: nowrap;
            display: inline-block;
            width: auto;
            margin-right: 10px;
        }

        .field-row {
            margin-bottom: 15px;
        }

        .page {
            display: none;
        }

        .page.active {
            display: block;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <form action="submit_form.php" method="POST" id="purchaseForm">
        <div class="container">
            <!-- Page 1: Comparative Statement -->
            <div id="page1" class="page active">
                <div class="header">
                    COLLEGE OF ENGINEERING, FARMAUDI - GOA, PONDA GOA<br>
                    Comparative Statement
                </div>
                <div class="fields">
                    <div class="field-left">
                        <div class="field-row">
                            <div class="field-label">Lab:</div>
                            <div class="field-input"><input type="text" name="lab" class="long-underline"></div>
                        </div>
                        <div class="field-row">
                            <div class="field-label">Dept:</div>
                            <div class="field-input"><input type="text" name="dept" class="long-underline"></div>
                        </div>
                    </div>
                    <div class="field-right">
                        <div class="field-row">
                            <div class="field-label">Date:</div>
                            <div class="field-input"><input type="date" name="date"></div>
                        </div>
                        <div class="field-row">
                            <div class="field-label">Ref:</div>
                            <div class="field-input"><input type="text" name="ref" class="long-underline"></div>
                        </div>
                    </div>
                    <div style="clear: both;"></div>
                </div>
                <table id="comparativeTable">
                    <tr>
                        <th>Sr. No.</th>
                        <th>Item</th>
                        <th>Qty</th>
                        <th colspan="2"><input type="text" name="ms_1" placeholder="M/s: ___________"></th>
                        <th colspan="2"><input type="text" name="ms_2" placeholder="M/s: ___________"></th>
                        <th colspan="2"><input type="text" name="ms_3" placeholder="M/s: ___________"></th>
                    </tr>
                    <tr>
                        <th> </th>
                        <th> </th>
                        <th> </th>
                        <th>Rate</th>
                        <th>Remarks</th>
                        <th>Rate</th>
                        <th>Remarks</th>
                        <th>Rate</th>
                        <th>Remarks</th>
                    </tr>
                    <tr>
                        <td><input type="text" name="sr_no_1"></td>
                        <td><input type="text" name="item_1"></td>
                        <td><input type="text" name="qty_1"></td>
                        <td><input type="text" name="rate_1"></td>
                        <td><input type="text" name="remarks_1"></td>
                        <td><input type="text" name="rate_2"></td>
                        <td><input type="text" name="remarks_2"></td>
                        <td><input type="text" name="rate_3"></td>
                        <td><input type="text" name="remarks_3"></td>
                    </tr>
                    <tr>
                        <td><input type="text" name="sr_no_2"></td>
                        <td><input type="text" name="item_2"></td>
                        <td><input type="text" name="qty_2"></td>
                        <td><input type="text" name="rate_4"></td>
                        <td><input type="text" name="remarks_4"></td>
                        <td><input type="text" name="rate_5"></td>
                        <td><input type="text" name="remarks_5"></td>
                        <td><input type="text" name="rate_6"></td>
                        <td><input type="text" name="remarks_6"></td>
                    </tr>
                    <tr>
                        <td><input type="text" name="sr_no_3"></td>
                        <td><input type="text" name="item_3"></td>
                        <td><input type="text" name="qty_3"></td>
                        <td><input type="text" name="rate_7"></td>
                        <td><input type="text" name="remarks_7"></td>
                        <td><input type="text" name="rate_8"></td>
                        <td><input type="text" name="remarks_8"></td>
                        <td><input type="text" name="rate_9"></td>
                        <td><input type="text" name="remarks_9"></td>
                    </tr>
                    <tr>
                        <td><input type="text" name="sr_no_4"></td>
                        <td><input type="text" name="item_4"></td>
                        <td><input type="text" name="qty_4"></td>
                        <td><input type="text" name="rate_10"></td>
                        <td><input type="text" name="remarks_10"></td>
                        <td><input type="text" name="rate_11"></td>
                        <td><input type="text" name="remarks_11"></td>
                        <td><input type="text" name="rate_12"></td>
                        <td><input type="text" name="remarks_12"></td>
                    </tr>
                </table>
                <div class="notes">
                    <p>Abbreviations :- As per Specifications ..... APS</p>
                    <p>Not As per Specifications ..... NAPS</p>
                </div>
                <div class="button-container">
                    <button type="button" class="nav-button" onclick="showPage('page2')">Next Page</button>
                    <button type="button" class="nav-button">Send Form</button>
                </div>
            </div>

            <!-- Page 2: Recommendations -->
            <div id="page2" class="page">
                <div class="header">
                    RECOMMENDATIONS - FINAL RECOMMENDATION BY THE PROFESSOR IN CHARGE
                </div>
                <table id="recommendationTable">
                    <tr>
                        <th>Name of the Firm</th>
                        <th>Item No.</th>
                        <th>Qty.</th>
                        <th>Rate</th>
                        <th>Amount</th>
                        <th>Recommendation</th>
                    </tr>
                    <tr>
                        <td><input type="text" name="firm"></td>
                        <td><input type="text" name="item_no"></td>
                        <td><input type="text" name="qty"></td>
                        <td><input type="text" name="rate"></td>
                        <td><input type="text" name="amount"></td>
                        <td><input type="text" name="recommendation"></td>
                    </tr>
                </table>
                <div class="fields" style="margin-top: 20px;">
                    <div class="field-row">
                        <div class="field-label single-line-label">Name of Lab:</div>
                        <div class="field-input"><input type="text" name="lab_name" class="long-underline"></div>
                    </div>
                    <div class="field-row">
                        <div class="field-label single-line-label">Professor In Charge Name:</div>
                        <div class="field-input"><input type="text" name="professor_name" class="long-underline"></div>
                    </div>
                </div>
                <div class="button-container">
                    <button type="button" class="nav-button" onclick="showPage('page1')">Previous Page</button>
                    <button type="submit" class="nav-button">Save</button>
                </div>
            </div>
        </div>
    </form>

    <script>
        function showPage(pageId) {
            const pages = document.querySelectorAll('.page');
            pages.forEach(page => page.classList.remove('active'));
            document.getElementById(pageId).classList.add('active');
        }
        showPage('page1'); // Start on Page 1
    </script>
</body>

</html>
