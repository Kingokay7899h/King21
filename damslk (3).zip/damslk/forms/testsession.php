<?php
session_start();
$_SESSION['email'] = 'rigvednaik22167@gmail.com';
$_SESSION['role'] = 'Lab faculty incharge';
echo "Session Set! Refresh this page and see if it persists.";
?>
