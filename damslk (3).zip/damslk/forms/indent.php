<?php
session_start();

if (!isset($_SESSION['user_role'])) {
    $_SESSION['user_role'] = 'hod'; // Change this to 'store_admin' or 'dept_assistant' to test other roles
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Indent Book</title>
    <link rel="stylesheet" href="indstyle.css">
</head>
<body>
    <div class="form-container">
        <h1>Indent Book</h1>
        <p class="subtitle">Indent cum invoice for the supply of stores.</p>

        <form action="process_indent.php" method="POST">
            <div class="indent">
                <label for="num">Indent No.:</label>
                <input type="text" id="num" name="indent_no" placeholder="Enter number" required>
            </div>

            <h5>To</h5>
            <h5>The Store Keeper</h5>

            <div class="form-grid">
                <div class="form-column">
                    <div class="form-section">
                        <label for="material">Name & Specification of Material</label>
                        <textarea id="material" name="material" placeholder="Enter material details" required></textarea>
                    </div>

                    <div class="form-row">
                        <div class="form-section">
                            <label for="quantity-required">Quantity Required</label>
                            <input type="number" id="quantity-required" name="quantity_required" placeholder="Enter quantity required" required>
                        </div>

                        <div class="form-section">
                            <label for="quantity-issued">Quantity Issued</label>
                            <input type="number" id="quantity-issued" name="quantity_issued" placeholder="Enter quantity issued" required>
                        </div>
                    </div>
                </div>

                <div class="form-column">
                    <div class="form-section">
                        <label for="date">Date</label>
                        <input type="date" id="date" name="date" required>
                    </div>

                    <div class="form-section">
                        <label for="department">Department</label>
                        <input type="text" id="department" name="department" placeholder="Enter department name" required>
                    </div>

                    <div class="sub">
                <button type="submit">Submit</button>
                </div>
                </div>
                
            </div>
        </form>

        <hr>

        <h3>Approval Status</h3>
        <p><strong>Current Status:</strong> <span id="statusDisplay">Pending Approval</span></p>

        <?php
        if (isset($_SESSION['user_role'])) {
            if ($_SESSION['user_role'] == 'hod') {
                echo '<button onclick="approveForm(\'approve_hod\')">Approve (HOD)</button>';
            }
            if ($_SESSION['user_role'] == 'store_admin') {
                echo '<button onclick="approveForm(\'issue_store\')">Issue Asset (Stores Admin)</button>';
            }
            if ($_SESSION['user_role'] == 'dept_assistant') {
                echo '<input type="text" id="otpInput" placeholder="Enter OTP">';
                echo '<button onclick="approveForm(\'confirm_receipt\')">Confirm Receipt</button>';
            }
        }
        ?>
    </div>

    <script>
        function approveForm(action) {
            let indent_no = prompt("Enter Indent number:");
            if (!indent_no) {
                alert("Indent no. is required!");
                return;
            }

            let otp = (action === 'confirm_receipt') ? document.getElementById("otpInput").value : '';

            fetch("process_indent.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: new URLSearchParams({ indent_no: indent_no , action: action, otp: otp })
            })
            .then(response => response.text())
            .then(data => {
                alert(data);
                location.reload();
            })
            .catch(error => console.error("Error:", error));
        }
    </script>
</body>
</html>