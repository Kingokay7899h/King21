<?php
// Database connection details
$servername = "localhost";
$username = "root"; // Default username for WAMP
$password = ""; // Default password for WAMP
$dbname = "asset_management";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Debugging: Check the date value
    echo "Date received: " . $_POST['date']; // Debugging line

    // Format the date to YYYY-MM-DD
    $date = $_POST['date'];
    $date = date('Y-m-d', strtotime($date)); // Ensure correct format

    // Insert data into Comparative_statement table
    $lab = $_POST['lab'] ?? null;
    $dept = $_POST['dept'] ?? null;
    $ref = $_POST['ref'] ?? null;
    $ms_1 = $_POST['ms_1'] ?? null;
    $ms_2 = $_POST['ms_2'] ?? null;
    $ms_3 = $_POST['ms_3'] ?? null;
    $sr_no_1 = $_POST['sr_no_1'] ?? null;
    $item_1 = $_POST['item_1'] ?? null;
    $qty_1 = $_POST['qty_1'] ?? null;
    $rate_1 = $_POST['rate_1'] ?? null;
    $remarks_1 = $_POST['remarks_1'] ?? null;
    $rate_2 = $_POST['rate_2'] ?? null;
    $remarks_2 = $_POST['remarks_2'] ?? null;
    $rate_3 = $_POST['rate_3'] ?? null;
    $remarks_3 = $_POST['remarks_3'] ?? null;
    $sr_no_2 = $_POST['sr_no_2'] ?? null;
    $item_2 = $_POST['item_2'] ?? null;
    $qty_2 = $_POST['qty_2'] ?? null;
    $rate_4 = $_POST['rate_4'] ?? null;
    $remarks_4 = $_POST['remarks_4'] ?? null;
    $rate_5 = $_POST['rate_5'] ?? null;
    $remarks_5 = $_POST['remarks_5'] ?? null;
    $rate_6 = $_POST['rate_6'] ?? null;
    $remarks_6 = $_POST['remarks_6'] ?? null;
    $sr_no_3 = $_POST['sr_no_3'] ?? null;
    $item_3 = $_POST['item_3'] ?? null;
    $qty_3 = $_POST['qty_3'] ?? null;
    $rate_7 = $_POST['rate_7'] ?? null;
    $remarks_7 = $_POST['remarks_7'] ?? null;
    $rate_8 = $_POST['rate_8'] ?? null;
    $remarks_8 = $_POST['remarks_8'] ?? null;
    $rate_9 = $_POST['rate_9'] ?? null;
    $remarks_9 = $_POST['remarks_9'] ?? null;
    $sr_no_4 = $_POST['sr_no_4'] ?? null;
    $item_4 = $_POST['item_4'] ?? null;
    $qty_4 = $_POST['qty_4'] ?? null;
    $rate_10 = $_POST['rate_10'] ?? null;
    $remarks_10 = $_POST['remarks_10'] ?? null;
    $rate_11 = $_POST['rate_11'] ?? null;
    $remarks_11 = $_POST['remarks_11'] ?? null;
    $rate_12 = $_POST['rate_12'] ?? null;
    $remarks_12 = $_POST['remarks_12'] ?? null;

    // Insert into Comparative_statement table
    $sql = "INSERT INTO Comparative_statement (lab, dept, date, ref, ms_1, ms_2, ms_3, sr_no_1, item_1, qty_1, rate_1, remarks_1, rate_2, remarks_2, rate_3, remarks_3, sr_no_2, item_2, qty_2, rate_4, remarks_4, rate_5, remarks_5, rate_6, remarks_6, sr_no_3, item_3, qty_3, rate_7, remarks_7, rate_8, remarks_8, rate_9, remarks_9, sr_no_4, item_4, qty_4, rate_10, remarks_10, rate_11, remarks_11, rate_12, remarks_12, created_at)
            VALUES ('$lab', '$dept', '$date', '$ref', '$ms_1', '$ms_2', '$ms_3', '$sr_no_1', '$item_1', '$qty_1', '$rate_1', '$remarks_1', '$rate_2', '$remarks_2', '$rate_3', '$remarks_3', '$sr_no_2', '$item_2', '$qty_2', '$rate_4', '$remarks_4', '$rate_5', '$remarks_5', '$rate_6', '$remarks_6', '$sr_no_3', '$item_3', '$qty_3', '$rate_7', '$remarks_7', '$rate_8', '$remarks_8', '$rate_9', '$remarks_9', '$sr_no_4', '$item_4', '$qty_4', '$rate_10', '$remarks_10', '$rate_11', '$remarks_11', '$rate_12', '$remarks_12', NOW())";

    if ($conn->query($sql)) {
        $comparative_id = $conn->insert_id; // Get the last inserted ID

        // Insert data into Recommendations table
        $firm = $_POST['firm'] ?? null;
        $item_no = $_POST['item_no'] ?? null;
        $qty = $_POST['qty'] ?? null;
        $rate = $_POST['rate'] ?? null;
        $amount = $_POST['amount'] ?? null;
        $recommendation = $_POST['recommendation'] ?? null;
        $lab_name = $_POST['lab_name'] ?? null;
        $professor_name = $_POST['professor_name'] ?? null;

        $sql = "INSERT INTO Recommendations (comparative_id, firm, item_no, qty, rate, amount, recommendation, lab_name, professor_name, created_at)
                VALUES ('$comparative_id', '$firm', '$item_no', '$qty', '$rate', '$amount', '$recommendation', '$lab_name', '$professor_name', NOW())";

        if ($conn->query($sql)) {
            echo "Data inserted successfully!";
        } else {
            echo "Error inserting into Recommendations: " . $conn->error;
        }
    } else {
        echo "Error inserting into Comparative_statement: " . $conn->error;
    }

    // Close connection
    $conn->close();
}
?>
