<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'phpmailer-master/src/PHPMailer.php';
require 'phpmailer-master/src/SMTP.php';
require 'phpmailer-master/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Database Connection
$conn = new mysqli("localhost", "root", "", "asset_management");
if ($conn->connect_error) {
    die("❌ Database Connection Failed: " . $conn->connect_error);
}

// Handle form submission (Saving Indent Form)
if ($_SERVER["REQUEST_METHOD"] == "POST" && !isset($_POST['action'])) {
    $stmt = $conn->prepare("INSERT INTO indent_forms (indent_no, material, quantity_required, quantity_issued, department, date, status)
                            VALUES (?, ?, ?, ?, ?, ?, 'Pending Approval')");
    $stmt->bind_param("ssssss", $_POST['indent_no'], $_POST['material'], $_POST['quantity_required'],
                      $_POST['quantity_issued'], $_POST['department'], $_POST['date']);

    if ($stmt->execute()) {
        echo "✅ Indent form submitted successfully!";
    } else {
        echo "❌ Database Insert Error: " . $stmt->error;
    }
}

// Handle Approvals (HOD, Stores, Department Assistant)
if (isset($_POST['action']) && isset($_POST['indent_no'])) {
    $indent_no = $_POST['indent_no'];

    // Get ID from indent_no
    $stmt = $conn->prepare("SELECT id FROM indent_forms WHERE indent_no = ?");
    $stmt->bind_param("s", $indent_no);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if (!$row) {
        die("❌ Error: Indent Number not found in the database.");
    }

    $id = $row['id']; // Correct database ID

    // Determine action status
    $status = match ($_POST['action']) {
        "approve_hod" => "Approved by HOD",
        "issue_store" => "Issued by Stores",
        "confirm_receipt" => "Received by Department",
        default => die("❌ Invalid Action"),
    };

    // Update status and timestamp
    $column = match ($_POST['action']) {
        "approve_hod" => "hod_approval_time",
        "issue_store" => "store_approval_time",
        "confirm_receipt" => "receiver_confirmation_time",
    };

    $stmt = $conn->prepare("UPDATE indent_forms SET status=?, $column=NOW() WHERE id=?");
    $stmt->bind_param("si", $status, $id);

    if ($stmt->execute()) {
        sendEmail("Indent Status Updated", "Status changed to: $status", "rigvednaik22167@gmail.com");
        echo "✅ Status Updated Successfully!";
    } else {
        echo "❌ Database Error: " . $stmt->error;
    }
}

// Handle OTP Confirmation
if (isset($_POST['generate_otp']) && isset($_POST['indent_no'])) {
    $indent_no = $_POST['indent_no'];
    $otp = rand(1000, 9999);

    // Get ID from indent_no
    $stmt = $conn->prepare("SELECT id FROM indent_forms WHERE indent_no = ?");
    $stmt->bind_param("s", $indent_no);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if (!$row) {
        die("❌ Error: Indent Number not found in the database.");
    }

    $id = $row['id'];

    // Store OTP in database
    $stmt = $conn->prepare("UPDATE indent_forms SET otp=? WHERE id=?");
    $stmt->bind_param("si", $otp, $id);

    if ($stmt->execute()) {
        sendEmail("OTP for Confirmation", "Your OTP is: $otp", "receiver@example.com");
        echo "✅ OTP sent successfully!";
    } else {
        echo "❌ Error generating OTP.";
    }
}

// Function to send email notifications
function sendEmail($subject, $message, $to) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'rigvednk10@gmail.com';
        $mail->Password = 'kdpi qkuk rypu fvtj';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('your-email@gmail.com', 'DAMS Notification');
        $mail->addAddress($to);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $message;

        $mail->send();
        echo "✅ Email sent!";
    } catch (Exception $e) {
        echo "❌ Email Error: " . $mail->ErrorInfo;
    }
}
?>