<?php

require '../forms/phpmailer-master/src/PHPMailer.php';
require '../forms/phpmailer-master/src/SMTP.php';
require '../forms/phpmailer-master/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

include '../Admin/db_config.php';

header('Content-Type: application/json'); // Ensure JSON response

$response = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['requisition_id'])) {
    $requisition_id = intval($_POST['requisition_id']);

    // Fetch requisition details
    $query = "SELECT cost FROM requisitions WHERE id = ? AND status = 'Pending Stores Officer Processing'";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $requisition_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $cost = intval($row['cost']);
        
        if ($cost < 25000) {
            // Update status to 'Sent to Committee'
            $updateQuery = "UPDATE requisitions SET status = 'Sent to Committee' WHERE id = ?";
            $updateStmt = $conn->prepare($updateQuery);
            $updateStmt->bind_param("i", $requisition_id);
            
            if ($updateStmt->execute()) {
                
                // Fetch Committee email
                $emailQuery = "SELECT email FROM users WHERE role = 'purchase Committee' LIMIT 1";
                $emailResult = $conn->query($emailQuery);
                
                if ($emailResult->num_rows > 0) {
                    $emailRow = $emailResult->fetch_assoc();
                    $committee_email = $emailRow['email'];

                    // Send email notification
                    $subject = "New Requisition Sent to Committee";
                    $message = "A new requisition (ID: $requisition_id) has been sent to the Committee for approval.";
                    $emailStatus = sendApprovalEmail($committee_email, $subject, $message);
                    
                    if ($emailStatus === true) {
                        $response = ["status" => "success", "message" => "Requisition approved and email sent."];
                    } else {
                        $response = ["status" => "warning", "message" => "Requisition approved but email failed: $emailStatus"];
                    }
                } else {
                    $response = ["status" => "warning", "message" => "Requisition approved, but no committee email found."];
                }
            } else {
                $response = ["status" => "error", "message" => "Error updating status."];
            }
        } else {
            $response = ["status" => "info", "message" => "Requisition above ₹25,000. Different processing required."];
        }
    } else {
        $response = ["status" => "error", "message" => "Invalid requisition or already processed."];
    }
} else {
    $response = ["status" => "error", "message" => "Invalid request."];
}

$conn->close();
echo json_encode($response);

function sendApprovalEmail($to, $subject, $message) {
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'rigvednk10@gmail.com';
        $mail->Password = 'kdpi qkuk rypu fvtj';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('rigvednk10@gmail.com', 'Asset Management System');
        $mail->addAddress($to);

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $message;

        $mail->send();
        return true;
    } catch (Exception $e) {
        return $mail->ErrorInfo; // Return error message for debugging
    }
}

?>
