<?php
include '../Admin/db_config.php';

$highCostData = [];
$lowCostData = [];

ob_start();
include 'rqformprocess.php';
$output = ob_get_clean();

$rows = explode('</tr>', $output);
foreach ($rows as $row) {
    if (strpos($row, '<td>') !== false) {
        preg_match_all('/<td>(.*?)<\/td>/', $row, $matches);
        if (!empty($matches[1])) {
            $cost = (int)filter_var($matches[1][10], FILTER_SANITIZE_NUMBER_INT);
            if ($cost >= 25000) {
                $highCostData[] = $row;
            } else {
                $lowCostData[] = $row;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pending Requisitions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h2>Pending Requisitions</h2>
        <h4>Requisitions ₹25,000 and Above</h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Lab Name</th>
                    <th>Stores Inward</th>
                    <th>Department</th>
                    <th>Date</th>
                    <th>Specification</th>
                    <th>Fund</th>
                    <th>Previous Purchase</th>
                    <th>Justification</th>
                    <th>Quantity</th>
                    <th>Cost</th>
                    <th>Suppliers</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php echo implode('</tr>', $highCostData) . '</tr>'; ?>
            </tbody>
        </table>

        <h4>Requisitions Below ₹25,000</h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Lab Name</th>
                    <th>Stores Inward</th>
                    <th>Department</th>
                    <th>Date</th>
                    <th>Specification</th>
                    <th>Fund</th>
                    <th>Previous Purchase</th>
                    <th>Justification</th>
                    <th>Quantity</th>
                    <th>Cost</th>
                    <th>Suppliers</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php echo implode('</tr>', $lowCostData) . '</tr>'; ?>
            </tbody>
        </table>
    </div>

    <script>
        document.querySelectorAll('.approve').forEach(button => {
            button.addEventListener('click', function () {
                let requisitionId = this.getAttribute('data-id');

                fetch('approvereq.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: 'requisition_id=' + encodeURIComponent(requisitionId)
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === "success") {
                        alert(data.message);
                        location.reload();
                    } else {
                        alert("Error: " + data.message);
                    }
                })
                .catch(error => alert("Request failed: " + error));
            });
        });
    </script>
</body>
</html>