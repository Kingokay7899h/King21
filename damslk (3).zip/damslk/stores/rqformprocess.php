<?php
include '../Admin/db_config.php';

$sql = "SELECT id, lab_name, storesInward, department, date, specification, fund, previous_purchase, justification, quantity, cost, suppliers, status FROM requisitions WHERE status = 'Pending Stores Officer Processing'";
$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row['id'] . "</td>
                <td>" . $row['lab_name'] . "</td>
                <td>" . $row['storesInward'] . "</td>
                <td>" . $row['department'] . "</td>
                <td>" . $row['date'] . "</td>
                <td>" . $row['specification'] . "</td>
                <td>" . $row['fund'] . "</td>
                <td>" . $row['previous_purchase'] . "</td>
                <td>" . $row['justification'] . "</td>
                <td>" . $row['quantity'] . "</td>
                <td>" . $row['cost'] . "</td>
                <td>" . $row['suppliers'] . "</td>
                <td><button class='btn btn-success approve' data-id='" . $row['id'] . "'>Approve</button></td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='13'>No pending requisitions</td></tr>";
}

$conn->close();
?>