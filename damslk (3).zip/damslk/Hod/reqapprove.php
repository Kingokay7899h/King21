// HOD Approval Script - Updates Status and Sends Email to Stores Officer
<?php
include '../Admin/db_config.php';
require '../forms/phpmailer-master/src/PHPMailer.php';
require '../forms/phpmailer-master/src/SMTP.php';
require '../forms/phpmailer-master/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['requisition_id'])) {
    $id = $_POST['requisition_id'];
    $status = "Pending Stores Officer Processing";

    // Update requisition status
    $stmt = $conn->prepare("UPDATE requisitions SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $id);

    if ($stmt->execute()) {
        echo "Requisition ID $id has been approved successfully by HOD.";
    } else {
        echo "Error updating record: " . $conn->error;
    }
    $stmt->close();

    // Fetch Stores Officer Email
    $role = "Store";
    $stmt = $conn->prepare("SELECT email FROM users WHERE role = ? LIMIT 1");
    $stmt->bind_param("s", $role);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stores_officer_email = $result['email'];
    $stmt->close();

    // Send email notification
    if (!empty($stores_officer_email)) {
        sendApprovalEmail($stores_officer_email, "Requisition Ready for Processing", "Requisition ID $id is awaiting your processing in the dashboard.");
    }
}
$conn->close();

// Email Function
function sendApprovalEmail($to, $subject, $message) {
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'rigvednk10@gmail.com';
        $mail->Password = 'kdpi qkuk rypu fvtj';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('rigvednk10@gmail.com', 'Asset Management System');
        $mail->addAddress($to);

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $message;

        $mail->send();
        return true;
    } catch (Exception $e) {
        return "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
