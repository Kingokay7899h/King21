<?php
include '../Admin/db_config.php';

$sql = "SELECT id,lab_name,specification, status FROM requisitions WHERE status = 'Pending HOD Approval'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['lab_name']}</td>
                <td>{$row['specification']}</td>
                <td>{$row['status']}</td>
                <td><button class='btn btn-success' onclick='approveRequisition({$row['id']})'>Approve</button></td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='5'>No pending approvals</td></tr>";
}
$conn->close();
?>
